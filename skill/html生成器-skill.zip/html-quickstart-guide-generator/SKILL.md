---
name: html生成器
description: |
  生成「图标化、章节编号化」的深色主题交互式 HTML 技术教程/快速入门指南的专用技能。当用户要求为某个技术工具/框架/库生成一份快速入门指南、学习路径、上手教程、实操教程（且期望输出为 HTML 格式）时触发。
  典型触发词：快速入门、入门指南、学习路径、上手教程、实操教程、帮我学XX、XX怎么入门、生成XX的入门文档、生成XX的HTML教程。
  输出特征：单文件 HTML，深色主题，带粘性导航栏、Hero 大标题+emoji+徽章、编号圆标章节（「第X章」）、带编号子标题、一键复制代码块（带语言标签）、Tab 切换、折叠面板、步骤列表、每章末尾「实操练习」块、方括号式排查卡片。风格参照 ADB工具使用实操教程.html。
  适用场景：pytest/requests/JMeter/Selenium/ADB/Fiddler/Redis/Docker/Git 等任何技术工具的快速入门与实操教程。
description_zh: "HTML 生成器（图标化深色技术教程）"
description_en: "HTML Generator (icon-rich dark tech tutorial)"
disable: false
agent_created: true
---

# HTML 生成器

将任意技术工具/框架/库的知识，蒸馏为一份**单文件、可独立运行、深色主题、图标化**的交互式 HTML 教程。输出风格统一参照 `ADB工具使用实操教程.html`——章节带编号与 emoji、子标题带编号、每章有「实操练习」、排查用方括号卡片、代码块带语言标签。

## When to use

- 用户要求为某个技术工具生成「快速入门」「入门指南」「学习路径」「上手教程」
- 用户希望输出为 HTML 格式（而非 Markdown / Word）
- 用户提到"和之前 pytest/requests/JMeter 一样的风格"
- 触发词示例：快速入门、入门指南、学习路径、上手教程、帮我学XX、XX怎么入门

## 核心设计系统

### CSS 变量（深色主题）

```css
:root {
  --bg: #0d1117;          /* 页面背景 */
  --bg-card: #161b22;     /* 卡片背景 */
  --bg-code: #0d1117;     /* 代码块背景 */
  --border: #30363d;      /* 边框 */
  --text: #c9d1d9;        /* 正文 */
  --text-muted: #8b949e;  /* 次要文字 */
  --text-heading: #f0f6fc;/* 标题 */
  --accent: #58a6ff;      /* 主色调（蓝） */
  --accent-green: #3fb950;
  --accent-orange: #d29922;
  --accent-red: #f85149;
  --accent-purple: #a371f7;
  --accent-cyan: #39d2c0;
  --radius: 8px;
}
```

### 语法高亮色

```css
.kw { color: #ff7b72; }      /* 关键字 */
.fn { color: #d2a8ff; }      /* 函数名 */
.str { color: #a5d6a7; }     /* 字符串 */
.cmt { color: #8b949e; }     /* 注释 */
.num { color: #79c0ff; }     /* 数字 */
.dec { color: #d2a8ff; }     /* 装饰器 */
.builtin { color: #ffa657; } /* 内置函数 */
```

## 图标化内容规范（核心，必须遵循）

输出风格对标 `ADB工具使用实操教程.html`。与朴素版本的**关键差异**在于内容层的图标化组织，而非 CSS（CSS 框架不变）。以下 7 条是标志性特征，逐条落实：

### 1. 章节标题用「第 X 章 + emoji + 标题」

每个 `<section>` 的 h2 用「第 X 章」中文编号，配一个贴合主题的 emoji，而非简短问句。

```html
<!-- ✅ 目标风格 -->
<h2><span class="num">1</span> 第 1 章 🤖 认识 ADB</h2>
<h2><span class="num">2</span> 第 2 章 🔌 设备连接管理</h2>
<!-- ❌ 朴素风格（避免） -->
<h2><span class="num">1</span> ADB 是什么？</h2>
```

### 2. 子标题带编号（X.Y 形式）

章节内的 h3 用「编号 + 图标 + 标题」，与章编号呼应。

```html
<h3>1.1 📌 什么是 ADB</h3>
<h3>1.2 🎯 核心用途</h3>
<h3>2.1 🔍 查看设备</h3>
```

### 3. 每章末尾加「✎ 实操练习」块

每章结束前放一个带图标的练习卡片，给出可动手的小任务，强化「实操教程」属性。

```html
<div class="card success">
  <strong>✎ 实操练习</strong>
  <ol>
    <li>连接手机后执行 <code>adb devices</code>，确认能看到设备序列号。</li>
    <li>尝试用 <code>adb reboot</code> 重启设备并观察。</li>
  </ol>
</div>
```

### 4. 排查/避坑用「方括号图标卡片」

故障排查、常见坑用带 <b>【图标 标题】</b> 方括号的卡片，视觉醒目，区别于普通提示。

```html
<div class="card warning">
  <b>⚠️【连不上排查】</b>
  <ul>
    <li>确认手机已开启「USB 调试」。</li>
    <li>换数据线 / 换 USB 口（部分线只供电）。</li>
    <li>执行 <code>adb kill-server &amp;&amp; adb start-server</code> 重启服务。</li>
  </ul>
</div>
```

### 5. 代码块 header 必须标语言/工具标签

`.code-block .header` 的 `<span>` 写清语言或工具名（Shell / Python / ADB / SQL / YAML 等），让读者一眼知道代码类型。

```html
<div class="code-block">
  <div class="header"><span>Shell · ADB</span><button class="copy-btn" onclick="copyCode(this)">📋 复制</button></div>
  <pre><code>adb devices</code></pre>
</div>
```

### 6. 状态/错误码用「状态 → 含义 → 解决」三列表

涉及状态码、错误码、返回值的，用三列解读表，而非简单两列对比。

```html
<table>
  <tr><th>状态/返回</th><th>含义</th><th>如何解决</th></tr>
  <tr><td><code>0</code></td><td>成功</td><td>—</td></tr>
  <tr><td><code>device not found</code></td><td>未识别到设备</td><td>检查连接、开启 USB 调试</td></tr>
</table>
```

### 7. 图标密度与选型

- 章标题、子标题、卡片标题、练习块、排查块**都要带 emoji/图标**，但正文段落不堆砌。
- 图标贴合语义：连接🔌、查看🔍、安装📦、运行▶️、警告⚠️、成功✅、提示💡、练习✎、命令⌨️、网络🌐、数据库🗄️、日志📜。
- 导航 brand 与 Hero 用同一个主 emoji。

## 页面结构（必须遵循）

```
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{工具名} 快速入门 — {副标题}</title>
  <style>/* 完整 CSS */</style>
</head>
<body>
  <!-- 1. 顶部导航栏 (sticky topnav) -->
  <nav class="topnav">
    <span class="brand">📦 工具名 入门</span>
    <a href="#intro">简介</a>
    <a href="#install">安装</a>
    ...（各章节锚点）
  </nav>

  <!-- 2. Hero 区域 -->
  <header class="hero">
    <span class="emoji">📦</span>
    <h1>工具名 快速入门</h1>
    <p class="subtitle">从零到能上手 — 面向XX工程师的实战学习路径</p>
    <div class="badges">
      <span class="badge">⏱ 约 X 天掌握</span>
      <span class="badge green">🧪 代码即文档</span>
      <span class="badge orange">🎯 上手即用</span>
    </div>
  </header>

  <!-- 3. 内容容器 -->
  <div class="container">
    <!-- 各章节 section -->
    <section id="intro">...</section>
    <section id="install">...</section>
    ...
  </div>

  <!-- 4. 交互脚本 -->
  <script>
    // switchTab() / copyCode() / scroll highlight
  </script>
</body>
</html>
```

## 章节模板（标准 10-13 章结构）

| 序号 | 章节 ID | 内容 |
|------|---------|------|
| 1 | `intro` | 简介 — 是什么、为什么用、对比表、核心概念速览 |
| 2 | `install` | 安装配置 — Tab 切换多平台/多方式、插件一览 |
| 3 | `core` / `concepts` | 核心概念 — 流程图 + 组件表 + 类比 |
| 4-8 | 按主题 | 功能详解 — 代码示例 + 卡片提示 + Tab 切换 |
| 9 | `commands` | 常用命令速查 |
| 10 | `practice` | 实战案例 — 步骤列表 + 完整代码 |
| 11 | `cheatsheet` | 速查卡 — 命令/快捷键/变量/函数 |
| 12 | `next` | 下一步学什么 |

## 交互组件清单

### 1. Tab 切换

```html
<div class="tabs">
  <button class="tab-btn active" onclick="switchTab('group', 'tab1')">选项1</button>
  <button class="tab-btn" onclick="switchTab('group', 'tab2')">选项2</button>
</div>
<div class="tab-content active" id="group-tab1">...</div>
<div class="tab-content" id="group-tab2">...</div>
```

### 2. 代码块 + 一键复制（带语言标签）

```html
<div class="code-block">
  <div class="header">
    <span class="lang lang-py">Python</span>   <!-- 语言标签：lang-py/lang-c/lang-cpp/lang-java/lang-shell 等 -->
    <span class="fname">文件名 / 说明</span>
    <button class="copy-btn" onclick="copyCode(this)">📋 复制</button>
  </div>
  <pre><code>
<span class="cmt"># 注释</span>
<span class="kw">def</span> <span class="fn">hello</span>():
    <span class="builtin">print</span>(<span class="str">"world"</span>)
  </code></pre>
</div>
```
语言标签配色：Python 绿 `.lang-py`、C 蓝 `.lang-c`、C++ 紫 `.lang-cpp`、Java 红 `.lang-java`、Shell 橙 `.lang-shell`。无明确语言时用默认 `.lang`（蓝）。

### 3. 卡片（4 种类型）

```html
<div class="card tip">💡 提示内容</div>
<div class="card warning">⚠️ 警告内容</div>
<div class="card success">✅ 成功/验证内容</div>
<div class="card info">📋 信息/补充内容</div>
```

### 4. 步骤列表

```html
<ol class="step-list">
  <li><strong>步骤标题</strong><p>详细说明</p></li>
  <li><strong>步骤标题</strong><p>详细说明</p></li>
</ol>
```

### 5. 折叠面板

```html
<details class="accordion">
  <summary>点击展开的标题</summary>
  <div class="accordion-body">展开后的内容</div>
</details>
```

### 6. 流程图（水平排列）

```html
<div class="flow">
  <div class="flow-box accent">步骤A<br><small>说明</small></div>
  <span class="flow-arrow">→</span>
  <div class="flow-box">步骤B<br><small>说明</small></div>
  <span class="flow-arrow">→</span>
  <div class="flow-box">步骤C<br><small>说明</small></div>
</div>
```

### 7. 时间线（学习路径用）

```html
<div class="timeline">
  <div class="timeline-item">
    <h4>Day 1 — 标题</h4>
    <p>内容</p>
  </div>
  <div class="timeline-item">
    <h4>Day 2 — 标题</h4>
    <p>内容</p>
  </div>
</div>
```

### 8. 表格

```html
<table>
  <tr><th>列1</th><th>列2</th><th>列3</th></tr>
  <tr><td>数据</td><td>数据</td><td><code>code</code></td></tr>
</table>
```

## JavaScript 交互（必须包含）

```javascript
// Tab 切换
function switchTab(group, tab) {
  document.querySelectorAll(`[id^="${group}-"]`).forEach(el => el.classList.remove('active'));
  document.getElementById(`${group}-${tab}`).classList.add('active');
  const btns = document.querySelectorAll('.tabs .tab-btn');
  btns.forEach(b => {
    if (b.getAttribute('onclick').includes(`'${tab}'`)) b.classList.add('active');
    else b.classList.remove('active');
  });
}

// 一键复制
function copyCode(btn) {
  const pre = btn.closest('.code-block').querySelector('pre');
  navigator.clipboard.writeText(pre.textContent).then(() => {
    btn.textContent = '✅ 已复制'; btn.classList.add('copied');
    setTimeout(() => { btn.textContent = '📋 复制'; btn.classList.remove('copied'); }, 2000);
  }).catch(() => {
    btn.textContent = '❌ 失败';
    setTimeout(() => { btn.textContent = '📋 复制'; }, 2000);
  });
}

// 导航高亮
const sections = document.querySelectorAll('section[id]');
const navLinks = document.querySelectorAll('.topnav a');
window.addEventListener('scroll', () => {
  let current = '';
  sections.forEach(s => {
    if (window.scrollY >= s.offsetTop - 80) current = s.getAttribute('id');
  });
  navLinks.forEach(a => {
    a.classList.remove('active');
    if (a.getAttribute('href') === `#${current}`) a.classList.add('active');
  });
});
```

## Steps

1. **确认主题与受众**：明确要介绍的技术工具、目标读者（测试工程师/开发者/运维等）、预计学习天数
2. **规划章节结构**：根据工具特点确定 8-13 个章节，确保从"是什么→安装→核心概念→功能详解→实战→速查"的递进逻辑；为每章分配「第 X 章」编号与一个主题 emoji
3. **收集知识内容**：整理该工具的核心知识点、常用命令、代码示例、实战场景、常见报错与排查方法
4. **编写 HTML 文件**：
   - 使用 `@templates/base-template.html` 作为骨架
   - 章标题用「第 X 章 + emoji + 标题」，子标题用「X.Y + 图标 + 标题」
   - 代码块 header 必须标语言/工具标签（Shell / Python / ADB 等）
   - 代码示例必须完整可运行、带语法高亮 span
   - 每个章节至少包含 1 个代码块 + 1 个对比表或卡片
5. **补充图标化组件**：
   - 每章末尾加「✎ 实操练习」块（success 卡片）
   - 故障/避坑用「⚠️【方括号标题】」排查卡片（warning 卡片）
   - 状态码/错误码用「状态→含义→解决」三列表
6. **添加交互组件**：Tab 切换（多平台安装/多种用法）、折叠面板（进阶内容）、步骤列表（操作流程）
7. **输出文件**：写入 `{tool-name}-quickstart-guide.html`（或用户指定名，如「XX实操教程.html」）到工作目录
8. **调用 present_files** 展示给用户

## Pitfalls

- **不要使用外部 CDN**：单文件必须完全自包含，不依赖任何外部资源
- **不要用 emoji 做 HTML ID**：ID 必须 ASCII，emoji 只出现在标题/brand/卡片文本中
- **代码块中的 `<` `>` 要转义**：使用 `&lt;` `&gt;` 避免被解析为 HTML 标签
- **Tab 的 group 名不能重复**：`switchTab('group', 'tab')` 的 group 必须唯一
- **导航锚点必须与 section id 对应**：`href="#intro"` 对应 `<section id="intro">`
- **响应式适配**：必须包含 `@media (max-width: 640px)` 断点
- **代码注释用中文**：注释说明"为什么这样做"而非"做了什么"
- **实战场景贴合用户背景**：如果用户是游戏测试工程师，示例用游戏相关场景
- **图标化不能省**：章标题/子标题/卡片/练习块/排查块必须带图标，这是本技能区别于朴素版本的核心特征——切勿只输出纯文字章节
- **编号要连贯**：章编号「第 X 章」与子标题「X.Y」必须对应一致，不能跳号
- **改造已有 HTML 时批量加图标/标签的坑**（重要）：
  - 用正则给已有页面加 emoji 或语言标签时，**必须严格限定作用域**。给章标题加 emoji 只能匹配 `<h2>...</h2>` 内部，绝不能全局匹配 `<span class="num">`——因为代码块的语法高亮也用 `class="num"`（数字着色），全局替换会把 emoji 注入代码内容，破坏代码。
  - 判断"标题是否已带 emoji"不能用 `ord(ch) > 0x2000`（会把中文 CJK 误判为 emoji 导致跳过），要用精确区间：`0x1F000–0x1FAFF`（表情）+ `0x2600–0x27BF`（杂项符号）+ `0x2190–0x21FF`（箭头）+ `0x2B00–0x2BFF`。
  - 语言标签按文件扩展名判断时，fname 可能是 `xxx.cpp → 说明` 复合形式，要先取 `→` 前主体再判扩展名；无明确后缀时按所在章节设默认语言（如 C++ 章节默认 C++）。
  - 处理前务必 `.bak` 备份，处理后用脚本校验：标签平衡（div/section/pre 开闭相等）、代码块 `<pre>` 内 emoji 污染数为 0。

## Verification

- 文件可直接在浏览器中打开运行（无需服务器）
- 所有 Tab 切换正常
- 复制按钮点击后显示"已复制"
- 导航栏滚动高亮正确
- 代码块内容完整、语法高亮 span 正确包裹
- 移动端（缩小窗口）布局不溢出

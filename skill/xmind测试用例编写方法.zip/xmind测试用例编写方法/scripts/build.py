# -*- coding: utf-8 -*-
"""测试用例 -> XMind 思维导图 + 配套 HTML 预览器 通用生成器

数据驱动：读取一份 JSON 用例规格，同时产出两个文件：
  1) <name>.xmind          —— XMind Zen 格式（content.json + metadata.json + manifest.json）
  2) <name>-思维导图.html   —— 深色主题、可折叠/缩放/平移、支持上传解析其它 .xmind

层级（链式）：模块 → 功能点 → 测试点 → 前提条件 → 操作步骤 → 预期结果
可选：根下前置一个「档位/参数定义」分支（gears 字段）。

用法：
  python build.py <spec.json> <output_dir> [--basename 文件名前缀]

spec.json 结构见 references/spec_format.md。
仅依赖标准库（json/zipfile/uuid/os/sys），无需 openpyxl / jszip 等第三方包。
"""
import json, zipfile, uuid, os, sys, argparse


def nid():
    return uuid.uuid4().hex[:20]


def topic(title, children=None):
    t = {"id": nid(), "class": "topic", "title": title}
    if children:
        t["children"] = {"attached": children}
    return t


def build_xmind(spec, out_path):
    """根据 spec 生成 .xmind 文件。"""
    root_title = spec.get("title", "测试用例（E3未验证）")
    sheet_title = spec.get("sheet_title", "测试用例")

    root_children = []

    # 档位/参数定义分支（可选）
    gears = spec.get("gears") or []
    if gears:
        gear_label = spec.get("gears_branch_label", "档位定义")
        gear_nodes = [topic(f"{g['name']}：{g['param']}") for g in gears]
        root_children.append(topic(gear_label, gear_nodes))

    total = 0
    for mod in spec["modules"]:
        func_nodes = []
        for func in mod["functions"]:
            tp_nodes = []
            for t in func["tests"]:
                # 链式：测试点 → 前提条件 → 操作步骤 → 预期结果
                cur = topic(t["exp"])                       # 预期结果
                cur = topic(t["step"], children=[cur])      # 操作步骤
                cur = topic(t["pre"], children=[cur])       # 前提条件
                tp_nodes.append(topic(t["tp"], children=[cur]))  # 测试点
                total += 1
            func_nodes.append(topic(func["name"], tp_nodes))
        root_children.append(topic(mod["name"], func_nodes))

    root = topic(root_title, root_children)
    sheet_id = nid()
    content = [{
        "id": sheet_id,
        "class": "sheet",
        "title": sheet_title,
        "rootTopic": root,
        "topicPositioning": "fixed",
    }]
    metadata = {
        "creator": {"name": "testcase-xmind-generator", "version": "1.0"},
        "activeSheetId": sheet_id,
    }
    manifest = {"file-entries": {
        "content.json": {}, "metadata.json": {}, "manifest.json": {},
    }}

    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("content.json", json.dumps(content, ensure_ascii=False))
        z.writestr("metadata.json", json.dumps(metadata, ensure_ascii=False))
        z.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False))
    return total, len(spec["modules"])


# ---------------- HTML 预览器 ----------------
HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>__TITLE__ · 思维导图</title>
<script src="https://cdn.jsdelivr.net/npm/jszip@3.10.1/dist/jszip.min.js"></script>
<style>
  :root {{
    --bg:#0d1117; --panel:#161b22; --border:#30363d; --text:#c9d1d9;
    --muted:#8b949e; --accent:#58a6ff; --gear:#bc8cff;
  }}
  * {{ box-sizing:border-box; }}
  body {{ margin:0; font-family:"Microsoft YaHei","PingFang SC",system-ui,sans-serif;
         background:var(--bg); color:var(--text); }}
  header {{ position:sticky; top:0; z-index:10; background:rgba(13,17,23,.92);
           backdrop-filter:blur(8px); border-bottom:1px solid var(--border);
           padding:10px 16px; display:flex; align-items:center; gap:12px; flex-wrap:wrap; }}
  header h1 {{ font-size:16px; margin:0; font-weight:600; }}
  header .badge {{ color:var(--muted); font-size:12px; }}
  .spacer {{ flex:1; }}
  button {{ background:var(--panel); color:var(--text); border:1px solid var(--border);
           padding:6px 12px; border-radius:6px; cursor:pointer; font-size:13px; }}
  button:hover {{ border-color:var(--accent); color:var(--accent); }}
  #canvas {{ padding:20px; overflow:auto; }}
  #tree ul {{ list-style:none; margin:0; padding-left:22px; }}
  #tree > ul {{ padding-left:0; }}
  #tree li {{ position:relative; margin:4px 0; }}
  #tree li::before {{ content:""; position:absolute; left:-14px; top:12px;
                     width:10px; height:1px; background:var(--border); }}
  #tree li::after {{ content:""; position:absolute; left:-14px; top:-6px; bottom:0;
                    width:1px; background:var(--border); }}
  #tree > ul > li::after {{ display:none; }}
  .node {{ display:inline-flex; align-items:center; gap:6px; padding:5px 10px;
          background:var(--panel); border:1px solid var(--border); border-radius:6px;
          cursor:default; font-size:13px; line-height:1.4; max-width:760px; }}
  .node.toggle {{ cursor:pointer; }}
  .node.toggle::before {{ content:"▾"; color:var(--muted); font-size:11px; width:12px; }}
  .node.collapsed::before {{ content:"▸"; }}
  .node .txt {{ white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }}
  #tree li.collapsed > ul {{ display:none; }}
  .gear-node {{ border-color:var(--gear); color:var(--gear); }}
  #stat {{ position:fixed; bottom:12px; left:12px; background:var(--panel);
          border:1px solid var(--border); border-radius:6px; padding:6px 12px;
          font-size:12px; color:var(--muted); }}
  #drop {{ position:fixed; inset:0; background:rgba(88,166,255,.12);
          border:2px dashed var(--accent); display:none; align-items:center;
          justify-content:center; z-index:100; font-size:20px; color:var(--accent); }}
  #drop.show {{ display:flex; }}
</style>
</head>
<body>
<header>
  <h1>🧠 __TITLE__</h1>
  <span class="badge">共 __TOTAL__ 条用例 · __MODS__ 个模块__GEARS_LABEL__</span>
  <span class="spacer"></span>
  <button onclick="expandAll(true)">全部展开</button>
  <button onclick="expandAll(false)">全部折叠</button>
  <button onclick="document.getElementById('file').click()">上传 .xmind</button>
  <input id="file" type="file" accept=".xmind" style="display:none" onchange="handleFile(this.files[0])">
</header>
<div id="canvas"><div id="tree"></div></div>
<div id="stat"></div>
<div id="drop">松开鼠标，上传 .xmind 预览</div>
<script>
const BUILTIN = __TREE_JSON__;
function renderTree(root){{
  const treeEl = document.getElementById('tree');
  treeEl.innerHTML='';
  const rootUl=document.createElement('ul');
  (root.c||[]).forEach(n=>rootUl.appendChild(makeLi(n,0)));
  treeEl.appendChild(rootUl);
  updateStat(root);
}}
function makeLi(node,level,isGear){{
  const li=document.createElement('li');
  const hasKids=node.c&&node.c.length>0;
  const div=document.createElement('div');
  let cls='node'+(hasKids?' toggle':'')+(isGear?' gear-node':'');
  div.className=cls;
  const txt=document.createElement('span'); txt.className='txt'; txt.textContent=node.t;
  div.appendChild(txt);
  li.appendChild(div);
  if(hasKids){{
    const ul=document.createElement('ul');
    node.c.forEach(c=>ul.appendChild(makeLi(c,level+1,isGear)));
    li.appendChild(ul);
    div.addEventListener('click',()=>{{
      li.classList.toggle('collapsed');
      div.classList.toggle('collapsed');
    }});
  }}
  return li;
}}
function expandAll(open){{
  document.querySelectorAll('#tree li').forEach(li=>{{
    if(li.querySelector('ul')){{ li.classList.toggle('collapsed',!open);
      const d=li.querySelector('.node'); if(d) d.classList.toggle('collapsed',!open); }}
  }});
}}
function updateStat(root){{
  let total=0,mods=0;
  (root.c||[]).forEach(n=>{{ if(n.c&&n.c.length&&n.c[0].c) mods++; }});
  function count(node){{ if(node.c&&node.c.length){{ let leaf=0;
    node.c.forEach(c=>{{ if(c.c&&c.c.length) count(c); else leaf++; }});
    if(node.c[0] && node.c[0].c) {{}} else leaf++; return; }} }}
  // 简单统计：叶子（无子节点）视为用例条数
  (root.c||[]).forEach(m=>{{ if(m.c) m.c.forEach(f=>{{ if(f.c) f.c.forEach(tp=>{{
    if(tp.c) total++; }}); }}); }});
  document.getElementById('stat').textContent='共 '+total+' 条用例';
}}
function parseXmindContent(data){{
  // 兼容 XMind Zen：data 为数组，取 rootTopic，转 {t,c}
  function conv(t){{ return {{t:t.title, c:(t.children&&t.children.attached||[]).map(conv)}}; }}
  return conv(data[0].rootTopic);
}}
function renderFromTree(tree){{
  document.getElementById('tree').innerHTML='';
  const rootUl=document.createElement('ul');
  (tree.c||[]).forEach(n=>rootUl.appendChild(makeLi(n,0,false)));
  document.getElementById('tree').appendChild(rootUl);
}}
async function handleFile(file){{
  if(!file) return;
  if(typeof JSZip==='undefined'){{ alert('JSZip 未加载（离线时无法解析上传文件）'); return; }}
  const zip=await JSZip.loadAsync(file);
  const f=zip.file('content.json');
  if(!f){{ alert('未找到 content.json，可能不是有效的 .xmind 文件'); return; }}
  const data=JSON.parse(await f.async('string'));
  const tree=parseXmindContent(data);
  renderFromTree(tree);
}}
// 拖拽上传
const drop=document.getElementById('drop');
window.addEventListener('dragover',e=>{{e.preventDefault();drop.classList.add('show');}});
window.addEventListener('dragleave',e=>{{if(e.target===drop)drop.classList.remove('show');}});
window.addEventListener('drop',e=>{{e.preventDefault();drop.classList.remove('show');
  if(e.dataTransfer.files[0]) handleFile(e.dataTransfer.files[0]);}});
// 缩放
let scale=1;
document.getElementById('canvas').addEventListener('wheel',e=>{{
  if(e.ctrlKey){{ e.preventDefault(); scale=Math.min(1.6,Math.max(0.5,scale+(e.deltaY<0?0.05:-0.05)));
    document.getElementById('tree').style.transform='scale('+scale+')';
    document.getElementById('tree').style.transformOrigin='top left'; }}
}},{{passive:false}});
renderTree(BUILTIN);
</script>
</body>
</html>"""


def build_html(spec, tree, total, modules_count, out_path):
    root_title = spec.get("title", "测试用例")
    gears = spec.get("gears") or []
    gears_label = (" · " + str(len(gears)) + " 档") if gears else ""
    tree_json = json.dumps(tree, ensure_ascii=False)
    html = HTML_TEMPLATE
    html = html.replace("__TITLE__", root_title)
    html = html.replace("__TOTAL__", str(total))
    html = html.replace("__MODS__", str(modules_count))
    html = html.replace("__GEARS_LABEL__", gears_label)
    html = html.replace("__TREE_JSON__", tree_json)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html)


def build_tree_for_html(spec):
    """构建 HTML 用的 {t,c} 嵌套树（与 xmind 结构一致）。"""
    def testpoint(t):
        return {"t": t["tp"], "c": [
            {"t": t["pre"], "c": [
                {"t": t["step"], "c": [
                    {"t": t["exp"], "c": []},
                ]},
            ]},
        ]}
    root_children = []
    gears = spec.get("gears") or []
    if gears:
        gear_label = spec.get("gears_branch_label", "档位定义")
        root_children.append({
            "t": gear_label,
            "c": [{"t": f"{g['name']}：{g['param']}", "c": []} for g in gears],
        })
    for mod in spec["modules"]:
        fnodes = []
        for func in mod["functions"]:
            fnodes.append({"t": func["name"], "c": [testpoint(t) for t in func["tests"]]})
        root_children.append({"t": mod["name"], "c": fnodes})
    return {"t": spec.get("title", "测试用例"), "c": root_children}


def main():
    ap = argparse.ArgumentParser(description="测试用例 -> XMind + HTML 生成器")
    ap.add_argument("spec", help="JSON 用例规格路径")
    ap.add_argument("output_dir", help="输出目录")
    ap.add_argument("--basename", default="测试用例", help="输出文件名前缀")
    args = ap.parse_args()

    with open(args.spec, "r", encoding="utf-8") as f:
        spec = json.load(f)

    os.makedirs(args.output_dir, exist_ok=True)
    xmind_path = os.path.join(args.output_dir, f"{args.basename}.xmind")
    html_path = os.path.join(args.output_dir, f"{args.basename}-思维导图.html")

    total, mods = build_xmind(spec, xmind_path)
    tree = build_tree_for_html(spec)
    build_html(spec, tree, total, mods, html_path)

    print("SAVED:", xmind_path)
    print("SAVED:", html_path)
    print("模块数:", mods)
    print("用例总数:", total)


if __name__ == "__main__":
    main()

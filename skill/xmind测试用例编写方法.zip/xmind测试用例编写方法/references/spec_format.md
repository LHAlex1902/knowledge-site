# spec.json 用例规格格式说明

`scripts/build.py` 读取一份 JSON 规格，同时产出 `.xmind` 与配套 `-思维导图.html`。

## 顶层字段

| 字段 | 必填 | 说明 |
|------|------|------|
| `title` | 否 | 根节点标题，默认「测试用例（E3未验证）」。证据等级/项目名可并入此处 |
| `sheet_title` | 否 | XMind 画布标题，默认「测试用例」 |
| `gears` | 否 | 档位/参数定义数组；提供后会在根下生成一个「档位定义」分支 |
| `gears_branch_label` | 否 | 档位分支标题，默认「档位定义」 |
| `modules` | 是 | 模块数组，构成用例主体 |

## gears 结构

```json
"gears": [
  {"name": "弱网", "param": "下行1Mbps / 上行500kbps / 延迟150ms / 丢包5%"},
  {"name": "极差", "param": "下行100kbps / 上行50kbps / 延迟800ms / 丢包10%"},
  {"name": "100%丢包", "param": "丢包率100%（上行/下行全部丢弃），模拟完全隔离"}
]
```

## modules 结构（链式层级）

层级固定为：**模块 → 功能点 → 测试点 → 前提条件 → 操作步骤 → 预期结果**

```json
"modules": [
  {
    "name": "登录",
    "functions": [
      {
        "name": "账号登录",
        "tests": [
          {
            "tp":   "弱网下登录",
            "pre":  "账号正常",
            "step": "在弱网下点击登录",
            "exp":  "展示loading，超时后提示「网络异常请重试」，不崩溃、不卡死"
          }
        ]
      }
    ]
  }
]
```

每条 `test` 的四个字段对应链式的四层：
- `tp` 测试点（测试点节点，带优先级图标可在此体现，如标题含 [P0]）
- `pre` 前提条件
- `step` 操作步骤
- `exp` 预期结果

## 精简约定（可选）

- 若不需要「功能点」中间层，可让每个 module 只含一个 function。
- 若不需要档位分支，省略 `gears` 字段即可。
- 测试点/前提条件/操作步骤/预期结果里避免出现英文直引号 `"`（会破坏 JSON），用中文引号「」或"" 。

## 生成命令

```bash
python scripts/build.py <spec.json> <output_dir> --basename <文件名前缀>
```

产出：`<output_dir>/<前缀>.xmind` 与 `<output_dir>/<前缀>-思维导图.html`。

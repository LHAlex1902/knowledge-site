# -*- coding: utf-8 -*-
"""通用 N天学习计划 HTML 生成器（可移植版）。
用法：python gen_subject.py <days模块名> <phase模块名> <输出文件名> [输出目录]
  - days模块 需提供：META, PHASE_NAMES, DAYS
  - phase模块 需提供：PHASE_REVIEW, PHASE_PROBLEMS
  - 输出目录 可选，默认当前工作目录
复用高数的渲染逻辑与打卡同步 JS，只替换标题/图标/内容数据。内容与渲染分离，新增科目零改动本文件。"""
import sys, os, io, html as _h

def esc(s): return _h.escape(str(s), quote=False)

def make_render_problem():
    def f(p, idx):
        return (
          '<div class="qa">'
          '<div class="q"><span class="lab q">题目</span>'+esc(p["q"])+'</div>'
          '<div class="idea"><span class="lab idea">解题思路</span>'+esc(p["idea"])+'</div>'
          '<details class="ans"><summary><span class="lab ans">答案</span> 点击查看答案</summary>'
            '<div class="ans-body">'+esc(p["ans"])+'</div></details>'
          '<div class="mnemo"><span class="lab mn">口诀</span>'+esc(p["mnemo"])+'</div>'
          '</div>')
    return f

def make_build(meta, phase_names, phase_review, phase_problems, days):
    render_problem = make_render_problem()
    TOTAL = len(days)
    def render_day(d):
        parts=[]
        parts.append('<section class="day" id="day%d">'%d["day"])
        parts.append('<div class="day-head"><span class="day-no">第 %d 天</span>'
          '<span class="day-topic">%s</span>'
          '<span class="day-phase">阶段 %d · %s</span></div>'%(d["day"],esc(d["topic"]),d["phase"],esc(phase_names[d["phase"]])))
        parts.append('<div class="block"><h3 class="bt bt-kp">📖 知识点讲解</h3><ul class="kp-list">')
        for k in d["kp"]:
            parts.append('<li>'+esc(k)+'</li>')
        parts.append('</ul></div>')
        parts.append('<div class="block"><h3 class="bt bt-prac">✎ 小题巩固</h3>')
        for i,p in enumerate(d["problems"],1):
            parts.append(render_problem(p,i))
        parts.append('</div>')
        parts.append('<div class="block"><h3 class="bt bt-memo">🔖 重点速记</h3><ul class="memo-list">')
        for m in d["memo"]:
            parts.append('<li>'+esc(m)+'</li>')
        parts.append('</ul></div>')
        if d["day"]%3==0:
            parts.append('<div class="block phase"><h3 class="bt bt-phase">🏁 阶段 %d 总结 · 重点速记</h3>'
              '<div class="phase-review">%s</div></div>'%(d["phase"],esc(phase_review[d["phase"]])))
            parts.append('<div class="block phase"><h3 class="bt bt-phase">🧪 阶段 %d 综合题</h3>'%d["phase"])
            for i,p in enumerate(phase_problems[d["phase"]],1):
                parts.append(render_problem(p,i))
            parts.append('</div>')
        parts.append('<div class="day-foot">'
          '<button class="done-btn" onclick="markDone(%d,this)">✅ 确认学完第 %d 天</button>'
          '<span class="done-tip" id="tip%d"></span></div>'%(d["day"],d["day"],d["day"]))
        parts.append('</section>')
        return "".join(parts)

    def build():
        nav_days="".join('<a href="#day%d">第%d天</a>'%(d["day"],d["day"]) for d in days)
        html_parts=[]
        cur_phase=0
        for d in days:
            if d["phase"]!=cur_phase:
                cur_phase=d["phase"]
                html_parts.append('<div class="phase-intro"><b>阶段 %d · %s</b>：第 %d-%d 天</div>'%(
                  cur_phase,phase_names[cur_phase],(cur_phase-1)*3+1,cur_phase*3))
            html_parts.append(render_day(d))
        sections="".join(html_parts)

        favicon=('<link rel="icon" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 '
          'viewBox=%220 0 100 100%22><defs><linearGradient id=%22g%22 x1=%220%22 y1=%220%22 x2=%221%22 y2=%221%22>'
          '<stop offset=%220%22 stop-color=%22%2358a6ff%22/><stop offset=%221%22 stop-color=%22%23a371f7%22/>'
          '</linearGradient></defs><rect width=%22100%22 height=%22100%22 rx=%2222%22 fill=%22url(%23g)%22/>'
          '<text x=%2250%22 y=%2268%22 font-size=%2258%22 text-anchor=%22middle%22 dominant-baseline=%22central%22>'+meta["emoji"]+'</text></svg>" type="image/svg+xml">')
        L=[]
        L.append('<!DOCTYPE html>')
        L.append('<html lang="zh-CN">')
        L.append('<head>')
        L.append('<meta charset="UTF-8">')
        L.append('<meta name="viewport" content="width=device-width,initial-scale=1.0">')
        L.append('<title>'+meta["title"]+' · '+str(TOTAL)+'天学习计划</title>')
        L.append(favicon)
        L.append('<style>'+CSS+'</style>')
        L.append('</head>')
        L.append('<body>')
        L.append('<nav class="topnav"><div class="topnav-inner"><span class="brand">'+meta["emoji"]+' '+meta["brand"]+' '+str(TOTAL)+' 天</span>'+nav_days+'</div></nav>')
        L.append('<header class="hero"><span class="emoji">'+meta["emoji"]+'</span>')
        L.append('<h1><span class="grad">'+meta["title"]+'</span></h1>')
        L.append('<p class="sub">'+str(TOTAL)+' 天系统学习计划 · 每天：知识点讲解 → 小题巩固 → 重点速记 · 每 3 天阶段总结</p>')
        L.append('<div class="badges"><span class="badge">📅 共 <b>'+str(TOTAL)+'</b> 天</span>')
        L.append('<span class="badge">📚 <b>'+str(len(phase_names))+'</b> 大阶段</span>')
        L.append('<span class="badge">✅ 打卡进度可同步仓库</span></div></header>')
        L.append('<div class="progress-wrap"><div class="progress-bar"><div class="progress-fill" id="progFill"></div></div>')
        L.append('<div class="progress-text" id="progText">学习进度：0 / '+str(TOTAL)+' 天</div></div>')
        progress_file = meta.get("progress_file", "study-progress.json")  # 可配置子目录，如 "zikao/study-progress.json"
        L.append('<div class="sync-note">💾 打卡数据保存在本机，并同步至仓库 <code>'+esc(progress_file)+'</code>（需填入 GitHub PAT，与主页同一个令牌）</div>')
        L.append('<main class="container">'+sections+'</main>')
        L.append('<script>'+make_js(meta["ls_done"], TOTAL, progress_file)+'</script>')
        L.append('</body>')
        L.append('</html>')
        return "\n".join(L)
    return build

def make_js(ls_done, TOTAL, progress_file='study-progress.json'):
    tpl = """
var GH_USER='lhalex1902', GH_REPO='knowledge-site', SYNC_BRANCH='main';
var PROGRESS_FILE='__PROGRESS_FILE__';
var LS_TOKEN='zhishi-pulse-token-v1';
var LS_DONE='__LSDONE__';
var TOTAL=__TOTAL__;
function getToken(){try{return localStorage.getItem(LS_TOKEN)||'';}catch(e){return '';}}
function loadDone(){try{return JSON.parse(localStorage.getItem(LS_DONE)||'{}');}catch(e){return {};}}
function saveDone(obj){try{localStorage.setItem(LS_DONE,JSON.stringify(obj));}catch(e){}}
var DONE=loadDone();
function fmtSize(b){return b<1024?b+'B':(b<1048576?(b/1024).toFixed(1)+'KB':(b/1048576).toFixed(1)+'MB');}
function b64ToUtf8(b64){try{return decodeURIComponent(Array.prototype.map.call(atob(b64),function(c){return '%'+('00'+c.charCodeAt(0).toString(16)).slice(-2);}).join(''));}catch(e){return '';}}
function initProgress(){
  var done=0;
  for(var d=1;d<=TOTAL;d++){
    var btn=document.querySelector('.done-btn[onclick*="'+d+'"]');
    var tip=document.getElementById('tip'+d);
    if(DONE[d]){
      done++;
      if(btn){btn.disabled=true;btn.textContent='✓ 已学完第 '+d+' 天';}
      if(tip){tip.textContent='已完成 ✓';}
    }
  }
  updateBar(done);
}
function updateBar(done){
  var pct=Math.round(done/TOTAL*100);
  var fill=document.getElementById('progFill');
  var txt=document.getElementById('progText');
  if(fill){fill.style.width=pct+'%';}
  if(txt){txt.textContent='学习进度：'+done+' / '+TOTAL+' 天（'+pct+'%）';}
}
function markDone(day,btn){
  DONE[day]=1; saveDone(DONE);
  btn.disabled=true;btn.textContent='✓ 已学完第 '+day+' 天';
  var tip=document.getElementById('tip'+day);
  var done=Object.keys(DONE).length; updateBar(done);
  if(tip){tip.textContent='本地已记录，正在同步仓库…';tip.style.color='var(--accent)';}
  pushProgress(function(ok,msg){
    if(tip){
      if(ok){tip.textContent='已同步到仓库 ✓';tip.style.color='var(--accent)';}
      else{tip.textContent='本地已保存；仓库同步失败：'+(msg||'');tip.style.color='var(--orange)';}
    }
  });
}
function pushProgress(cb){
  var token=getToken();
  if(!token){cb(false,'未填入 PAT');return;}
  var url='https://api.github.com/repos/'+GH_USER+'/'+GH_REPO+'/contents/'+PROGRESS_FILE;
  function encodeContent(obj){return btoa(unescape(encodeURIComponent(JSON.stringify(obj))));}
  function putOnce(tryLeft){
    return fetch(url+'?ref='+SYNC_BRANCH+'&t='+Date.now(),{
        headers:{'Accept':'application/vnd.github+json','Authorization':'token '+token},cache:'no-store';})
      .then(function(r){ if(r.status===404)return {sha:null,content:null};
        return r.json().then(function(j){return {sha:(j&&j.sha)||null,content:(j&&j.content)||null};});})
      .then(function(ex){
        var cloud={};
        try{ if(ex.content) cloud=JSON.parse(b64ToUtf8(ex.content)); }catch(e){}
        var merged={};
        if(cloud && typeof cloud==='object'){ for(var k in cloud) merged[k]=cloud[k]; }
        for(var d in DONE) merged[d]=DONE[d];
        merged.updatedAt=new Date().toISOString();
        var payload={message:'study: 更新学习进度 '+new Date().toLocaleString('zh-CN'),
          content:encodeContent(merged),branch:SYNC_BRANCH};
        if(ex.sha) payload.sha=ex.sha;
        return fetch(url,{method:'PUT',headers:{'Accept':'application/vnd.github+json','Authorization':'token '+token},
          body:JSON.stringify(payload)}).then(function(rr){return rr.json().then(function(j){return {ok:rr.ok,status:rr.status,json:j};});});})
      .then(function(res){
        if(!res.ok && res.status===409 && tryLeft>0){
          return new Promise(function(resolve){setTimeout(function(){resolve(putOnce(tryLeft-1));},400+Math.random()*400);});
        }
        return res;
      });
  }
  putOnce(3).then(function(res){cb(res.ok, res.json && res.json.message);})
    .catch(function(err){cb(false,err.message);});
}
window.addEventListener('DOMContentLoaded',initProgress);
"""
    return tpl.replace('__LSDONE__', ls_done).replace('__TOTAL__', str(TOTAL)).replace('__PROGRESS_FILE__', progress_file)

CSS = """
:root{--bg:#0d1117;--bg2:#161b22;--card:#1c2128;--border:#30363d;--text:#c9d1d9;
--text2:#8b949e;--heading:#f0f6fc;--accent:#58a6ff;--accent2:#1f6feb;
--orange:#d29922;--red:#f85149;--purple:#a371f7;--radius:10px;
--ui-font:-apple-system,BlinkMacSystemFont,"Segoe UI","Microsoft YaHei","PingFang SC",sans-serif;}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:var(--ui-font);background:var(--bg);color:var(--text);line-height:1.75;-webkit-font-smoothing:antialiased}
strong,b{color:var(--red);font-weight:700}
.topnav{position:sticky;top:0;z-index:100;background:rgba(13,17,23,.82);backdrop-filter:blur(12px);
border-bottom:1px solid var(--border);padding:0 16px}
.topnav-inner{max-width:900px;margin:0 auto;display:flex;align-items:center;gap:14px;height:52px;overflow-x:auto}
.brand{font-weight:700;color:var(--heading);white-space:nowrap;font-size:15px}
.topnav a{color:var(--text2);text-decoration:none;font-size:13px;white-space:nowrap;padding:4px 6px;border-radius:6px}
.topnav a:hover{color:var(--accent)}
.hero{max-width:900px;margin:0 auto;padding:38px 20px 22px;text-align:center}
.hero .emoji{font-size:52px;display:block;margin-bottom:8px}
.hero h1{font-size:30px;color:var(--heading);font-weight:800;letter-spacing:-.5px}
.hero h1 .grad{background:linear-gradient(90deg,#58a6ff,#a371f7);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.hero .sub{color:var(--text2);margin-top:8px;font-size:14px}
.badges{display:flex;gap:8px;justify-content:center;flex-wrap:wrap;margin-top:16px}
.badge{background:var(--bg2);border:1px solid var(--border);border-radius:20px;padding:4px 12px;font-size:12.5px;color:var(--text)}
.badge b{color:var(--accent)}
.progress-wrap{max-width:900px;margin:0 auto 10px;padding:0 20px}
.progress-bar{height:8px;background:var(--bg2);border-radius:6px;overflow:hidden;border:1px solid var(--border)}
.progress-fill{height:100%;width:0;background:linear-gradient(90deg,#58a6ff,#a371f7);transition:width .4s}
.progress-text{color:var(--text2);font-size:12.5px;text-align:center;margin-top:6px}
.container{max-width:900px;margin:0 auto;padding:10px 20px 80px}
.phase-intro{background:var(--bg2);border:1px solid var(--border);border-left:3px solid var(--purple);
border-radius:var(--radius);padding:12px 16px;margin:26px 0 14px;font-size:13.5px;color:var(--text2)}
.phase-intro b{color:var(--purple)}
.day{background:var(--card);border:1px solid var(--border);border-radius:var(--radius);padding:18px 18px 8px;margin-bottom:16px}
.day-head{display:flex;align-items:center;gap:10px;flex-wrap:wrap;padding-bottom:12px;margin-bottom:12px;border-bottom:1px solid var(--border)}
.day-no{background:var(--accent2);color:#fff;font-weight:700;font-size:13px;padding:3px 10px;border-radius:6px;white-space:nowrap}
.day-topic{font-size:17px;font-weight:700;color:var(--heading)}
.day-phase{font-size:11.5px;color:var(--text2);margin-left:auto;background:var(--bg2);padding:2px 8px;border-radius:5px}
.block{margin-bottom:14px}
.bt{font-size:14.5px;font-weight:700;margin-bottom:8px;padding-left:10px;border-left:3px solid var(--accent)}
.bt-kp{border-color:var(--accent)}
.bt-prac{border-color:var(--orange)}
.bt-memo{border-color:var(--purple)}
.bt-phase{border-color:var(--red)}
.kp-list,.memo-list{list-style:none;padding-left:4px}
.kp-list li{position:relative;padding:6px 0 6px 22px;font-size:14px;border-bottom:1px dashed var(--border)}
.kp-list li:last-child{border-bottom:none}
.kp-list li::before{content:"▸";position:absolute;left:4px;color:var(--accent)}
.memo-list li{position:relative;padding:5px 0 5px 24px;font-size:13.5px;color:var(--text)}
.memo-list li::before{content:"★";position:absolute;left:3px;color:var(--orange);font-size:12px}
.qa{background:var(--bg2);border:1px solid var(--border);border-radius:8px;padding:12px 14px;margin-bottom:10px}
.qa .q{font-size:14px;color:var(--text);font-weight:600;margin-bottom:8px}
.lab{display:inline-block;font-size:11px;font-weight:700;padding:1px 7px;border-radius:4px;margin-right:6px;vertical-align:middle}
.lab.q{background:rgba(88,166,255,.16);color:var(--accent)}
.lab.idea{background:rgba(210,153,34,.16);color:var(--orange)}
.lab.ans{background:rgba(88,166,255,.16);color:var(--accent)}
.lab.mn{background:rgba(163,113,247,.16);color:var(--purple)}
.idea{font-size:13px;color:var(--text2);margin-bottom:8px}
.ans{margin-bottom:8px}
.ans summary{cursor:pointer;font-size:13px;color:var(--accent);list-style:none;user-select:none}
.ans summary::-webkit-details-marker{display:none}
.ans-body{font-size:13.5px;color:var(--text);margin-top:7px;padding:8px 10px;background:var(--card);border-radius:6px;border-left:2px solid var(--accent)}
.mnemo{font-size:12.5px;color:var(--purple);padding-top:6px;border-top:1px dashed var(--border)}
.phase{background:rgba(248,81,73,.05);border:1px solid rgba(248,81,73,.25);border-radius:8px;padding:12px 14px;margin-bottom:12px}
.phase-review{font-size:13.5px;color:var(--text);line-height:1.8}
.day-foot{display:flex;align-items:center;gap:12px;padding:12px 0 6px;border-top:1px solid var(--border);margin-top:6px}
.done-btn{background:linear-gradient(90deg,#1f6feb,#58a6ff);color:#fff;border:none;font-weight:700;
font-size:13.5px;padding:9px 16px;border-radius:8px;cursor:pointer;transition:.2s}
.done-btn:hover{filter:brightness(1.1);transform:translateY(-1px)}
.done-btn:disabled{background:var(--bg2);color:var(--text2);cursor:default;transform:none;filter:none;border:1px solid var(--border)}
.done-tip{font-size:12.5px;color:var(--accent)}
.sync-note{max-width:900px;margin:0 auto;padding:0 20px 10px;font-size:12px;color:var(--text2);text-align:center}
.sync-note a{color:var(--accent)}
@media(max-width:640px){
.hero h1{font-size:24px}.hero .emoji{font-size:42px}
.day-topic{font-size:15px}.day-phase{width:100%;margin-left:0}
.container{padding:10px 12px 60px}}
"""

if __name__ == '__main__':
    if len(sys.argv) < 4:
        print("用法: python gen_subject.py <days模块> <phase模块> <输出文件名> [输出目录]")
        sys.exit(1)
    mod_name = sys.argv[1]
    phase_name = sys.argv[2]
    out_name = sys.argv[3]
    out_dir = os.path.abspath(sys.argv[4]) if len(sys.argv) > 4 else os.getcwd()
    # 把输出目录加入模块搜索路径，便于找到同目录的数据文件（<科目>_days / <科目>_phase）
    if out_dir not in sys.path:
        sys.path.insert(0, out_dir)
    import importlib
    mod = importlib.import_module(mod_name)
    pmod = importlib.import_module(phase_name)
    # 优先从 phase 模块取 PHASE_REVIEW/PHASE_PROBLEMS，否则回退到 days 模块
    phase_review = getattr(pmod, 'PHASE_REVIEW', getattr(mod, 'PHASE_REVIEW', {}))
    phase_problems = getattr(pmod, 'PHASE_PROBLEMS', getattr(mod, 'PHASE_PROBLEMS', {}))
    build = make_build(mod.META, mod.PHASE_NAMES, phase_review, phase_problems, mod.DAYS)
    html_out = build()
    out_path = os.path.join(out_dir, out_name)
    with io.open(out_path, 'w', encoding='utf-8') as f:
        f.write(html_out)
    print("已生成:", out_path)
    print("文件大小:", len(html_out), "字符")

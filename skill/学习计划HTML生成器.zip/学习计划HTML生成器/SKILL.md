---
name: 学习计划HTML生成器
description: >
  生成「N天学习计划」单文件交互式 HTML 页面（默认 21 天，可任意天数），并为每个科目产出独立页面。
  每天贯彻"知识点讲解 → 小题巩固 → 重点速记"三段式，每 3 天一个阶段总结+综合题，题目统一按
  「题目 / 解题思路 / 答案 / 口诀」四段式呈现，末尾带"确认学完"打卡按钮，打卡数据可同步到 GitHub 仓库。
  当用户要求"做学习计划 HTML / N天学习路线 / 备考冲刺页面 / 把某科目整理成每日计划 / 打卡同步仓库"时触发。
  本技能提供参数化通用生成器（一份生成器 + 每科两份数据文件），可快速复用到任意科目。
agent_created: true
version: 1.0.0
---

# 21天（N天）学习计划 HTML 生成器

把一门科目的备考内容浓缩成一份**单文件、可打卡、可同步仓库**的深色主题交互式 HTML。
核心思想：**内容与渲染分离**——一份通用生成器 `gen_subject.py` 负责全部 HTML/CSS/JS 渲染，
每个科目只写两份纯数据文件（`<科目>_days.py` + `<科目>_phase.py`），命令行一键生成。

---

## 一、什么时候用这个技能

- 用户要把某科目（高数/英语/离散/操作系统/考研/公考……）整理成"N 天学习计划"网页。
- 用户要"每天：知识点 → 小题 → 速记"、"每 3 天一个阶段总结+综合题"这类结构化学习页面。
- 用户要打卡/进度能同步到 GitHub 仓库（复用同一个 PAT 令牌）。
- 用户已经做好一科，想**快速复制到其他科目**——这正是本技能的最大价值。

---

## 二、产物长什么样（页面结构）

```
顶部粘性导航 topnav（品牌 + 每天锚点跳转）
Hero 区（大 emoji + 渐变标题 + 副标题 + 徽章：共 N 天 / M 大阶段 / 可同步仓库）
进度条（本地打卡进度，实时百分比）
同步说明（提示 PAT 令牌）
主体 container：
  阶段介绍条 phase-intro（阶段 N · 名称：第 X-Y 天）
  每天一个 day 卡片：
    ├─ 📖 知识点讲解（kp 列表，面向 0 基础：是什么/为什么/怎么用）
    ├─ ✎ 小题巩固（每题四段式：题目/解题思路/答案(details折叠)/口诀）
    ├─ 🔖 重点速记（memo 列表）
    └─ 每 3 天追加：🏁 阶段总结速记 + 🧪 阶段综合题（默认每阶段 3 题）
    └─ ✅ 确认学完第 N 天 按钮（打卡 + 同步仓库）
```

样式：GitHub 深色开发者主题（`#0d1117` 底、蓝紫渐变强调色），字体用系统无衬线 + 微软雅黑，
**禁用绿色/青色/斜体/楷体**（与用户主页风格一致）。

---

## 三、文件清单（技能包内）

| 文件 | 作用 |
|------|------|
| `scripts/gen_subject.py` | **通用生成器**。读取数据模块，输出完整 HTML。所有科目共用它，不要改它。 |
| `scripts/example_days.py` | 数据文件模板：`META` / `PHASE_NAMES` / `DAYS`。每科复制一份来写。 |
| `scripts/example_phase.py` | 阶段数据模板：`PHASE_REVIEW` / `PHASE_PROBLEMS`。每科复制一份来写。 |
| `references/data_schema.md` | 数据字段完整说明 + 编写规范（四段式、0基础风格、命名约定）。 |
| `references/workflow.md` | 从素材(xlsx/docx)到成品 HTML 的完整工作流与踩坑清单。 |

---

## 四、最快上手（3 步出一科）

假设要做「物理 21 天」：

**第 1 步：准备数据文件**（放在工作目录，与生成器同目录或加到 sys.path）

```bash
cp scripts/example_days.py  wuli_days.py
cp scripts/example_phase.py wuli_phase.py
```

然后编辑 `wuli_days.py`：改 `META`（title/brand/emoji/ls_done），
按 `DAYS` 结构写 21 天内容；编辑 `wuli_phase.py`：写 7 个阶段的 `PHASE_REVIEW` 和 `PHASE_PROBLEMS`。
> 字段细节见 `references/data_schema.md`。

**第 2 步：一键生成**

```bash
python scripts/gen_subject.py wuli_days wuli_phase 物理21天学习计划.html
# 参数： <days模块名(不含.py)>  <phase模块名>  <输出文件名>
```

生成器会自动：渲染全部页面 → 内嵌打卡同步 JS（localStorage 键 = `META.ls_done`，仓库进度文件 = `study-progress.json`）。

**第 3 步：本地预览 + 体检**

```bash
python -m http.server 8899      # 在输出目录启动
# 浏览器打开 http://127.0.0.1:8899/物理21天学习计划.html
```

体检要点（见 workflow.md）：标签平衡、无禁色/斜体/楷体、天数正确、题目数 = 日常题 + 阶段题。

---

## 五、核心设计思路（复用的关键）

1. **内容与渲染分离**：生成器里没有任何具体科目内容，全部来自数据模块。
   新增科目 = 写两份数据文件，**零改动生成器**。这是能"高效完成、快速复用"的根本。

2. **数据模块约定**（每个科目固定两个文件）：
   - `<科目>_days.py` → `META`（标题/品牌/emoji/localStorage键）、`PHASE_NAMES`（阶段号→名）、`DAYS`（21 天列表）。
   - `<科目>_phase.py` → `PHASE_REVIEW`（阶段号→速记文本）、`PHASE_PROBLEMS`（阶段号→综合题列表）。
   - 每天 / 每题字段见 `references/data_schema.md`。

3. **打卡同步**：JS 用占位符 `__LSDONE__` / `__TOTAL__` 注入（**不要用 % 格式化**，JS 里的 `%` 会冲突）。
   同步逻辑：GitHub Contents API `PUT` + sha 乐观锁 + 409 冲突自动重试 3 次；首次打卡自动创建 `study-progress.json`。
   多科目共用同一仓库的 `study-progress.json`，用 `ls_done` 键区分本地缓存，进度合并到同一表。

4. **阶段节奏**：每 3 天为一个阶段（第 3/6/9…天尾部追加阶段总结+综合题）。
   阶段数 = 天数 / 3；`PHASE_NAMES`、`PHASE_REVIEW`、`PHASE_PROBLEMS` 的键必须与阶段号对齐。

---

## 六、其他有价值的内容（务必遵守）

- **面向 0 基础**：知识点先讲"是什么 / 为什么 / 直觉理解 / 怎么用"，再上题；题目解析分步骤（①②③）。
  用户明确反馈过"解析不够基础"，所以默认写详细、写具体，不要堆术语。
- **题目四段式是硬规范**：`q`(题目) / `idea`(解题思路) / `ans`(答案) / `mnemo`(口诀)，缺一不可。
  口诀要短、押韵或抓关键词，方便速记。
- **阶段题量**：默认每阶段 3 题（用户要求从 1 题加到 3 题），综合题要覆盖本阶段多个考点。
- **环境踩坑**：本机 bash 常有 shim 问题（ls/grep/cp/date 报 command not found），
  **优先用 Python 或专用工具（Read/Write/Glob/Grep）完成文件操作**，不要依赖 bash 管道。
- **生成器路径**：`gen_subject.py` 末尾 `out_path` 默认写死了绝对目录，复用到其他设备/目录时
  改成 `os.path.join(os.getcwd(), out_name)` 或让用户指定输出目录（见 workflow.md「移植到新设备」）。
- **字体/配色纪律**：中文用微软雅黑，禁用绿色(#3fb950 等)/青色/斜体/楷体，保持与用户主页一致。

---

## 七、移植到新设备

1. 整个 `study-plan-html-generator/` 目录拷贝到新设备的 `~/.workbuddy/skills/` 下即可。
2. 生成器依赖仅标准库（sys/io/html/importlib），任意 Python 3.8+ 可直接运行，无需 pip 安装。
3. 若输出目录不是 `site_publish`，修改 `gen_subject.py` 的 `out_path`（或用 workflow.md 里的改法）。
4. 打卡同步需要目标仓库的 GitHub PAT；若不同步仓库，可删除页面里的同步说明与 JS 中的 `pushProgress` 调用。

# 完整工作流（workflow）

从原始素材到成品 HTML 的端到端流程，以及历次踩过的坑。

---

## 一、端到端流程

```
素材(xlsx/docx/已有内容)
   │  ① 读取、提炼
   ▼
<科目>_days.py  +  <科目>_phase.py   （两份纯数据文件）
   │  ② 一键生成
   ▼
gen_subject.py <days> <phase> <输出.html> [输出目录]
   │  ③ 预览 + 体检
   ▼
成品 HTML（单文件，可打卡，可同步仓库）
   │  ④ 上线（可选）
   ▼
上传 GitHub Pages 仓库 + 强刷
```

### ① 读取素材
- Excel(.xlsx)：用 `openpyxl` 读取（`load_workbook` → 遍历 `iter_rows(values_only=True)`）。
- Word(.docx)：用 `python-docx` 或直接读取段落文本。
- 把素材内容按「天 → 知识点/题目/速记」结构重新组织，写进数据文件。
> 这一步是**内容创作**，最耗时。生成器只负责排版，内容质量取决于数据文件。

### ② 生成
```bash
python scripts/gen_subject.py wuli_days wuli_phase 物理21天学习计划.html /输出/目录
```
- 数据文件所在目录需在 `sys.path` 中（通常 cd 到数据文件目录再运行，或把生成器拷过去）。
- 生成器自动内嵌打卡同步 JS。

### ③ 预览 + 体检
```bash
python -m http.server 8899     # 在输出目录启动本地服务器
# 浏览器打开 http://127.0.0.1:8899/物理21天学习计划.html
```
体检项（用 Python 脚本检查，别用 bash grep）：
- **标签平衡**：`<section>`/`<div>`/`<details>` 开闭数量是否相等。
- **天数正确**：`day` section 数量 = 目标天数（21）。
- **题目总数** = 日常题(每天 problems 之和) + 阶段题(每阶段 3 题)。
- **无禁色/斜体/楷体**：不出现 `#3fb950` 等绿色/青色、`font-style:italic`、`KaiTi`/楷体。

### ④ 上线（可选）
- 把 HTML 上传到 GitHub Pages 仓库（如 `knowledge-site` 的 `tutorials/` 或根目录）。
- 用 GitHub Contents API `PUT`（需 PAT）或直接在网页端上传。
- 上传后强刷 Pages 缓存。

---

## 二、打卡同步机制（原理）

页面 JS 的打卡流程：
1. 点「确认学完第 N 天」→ 写入 localStorage（键 = `META.ls_done`）→ 立即更新进度条。
2. 调 `pushProgress()` 同步到仓库：
   - 读取仓库现有 `study-progress.json`（Contents API GET）。
   - 把本科目的打卡合并进总表（`{天:1,...}`），加 `updatedAt`。
   - `PUT` 写回，带 `sha` 做乐观锁。
   - 遇 409 冲突 → 自动重试 3 次（每次随机延迟，避免并发写冲突）。
3. 首次打卡时文件不存在（404）→ 自动创建。

**多科目共用一个 `study-progress.json`**：靠 `ls_done` 区分本地缓存，仓库总表合并所有科目进度。
PAT 令牌复用主页同一个（`LS_TOKEN`，默认 `zhishi-pulse-token-v1`）。

> 若不需要仓库同步：删除页面里的 `.sync-note` 说明，并去掉 JS 中 `markDone` 对 `pushProgress` 的调用即可，本地打卡仍正常工作。

---

## 三、踩坑清单（重要）

1. **bash shim 问题**：本机 bash 环境常报 `ls/grep/cp/date/netstat: command not found` 或 `dirname: null directory`。
   → **一律用 Python（os/shutil/subprocess）或专用工具（Read/Write/Glob/Grep）完成文件操作**，不要用 bash 管道。

2. **JS 里的 `%` 与 Python % 格式化冲突**：JS 的 URL 编码 `'%'+...` 若放在 Python `%` 格式化字符串里会报 `ValueError`。
   → 生成器已用占位符 `__LSDONE__` / `__TOTAL__` + `.replace()` 解决。**改 JS 时不要改回 % 格式化**。

3. **生成器输出路径**：原项目里 `out_path` 写死了 `site_publish` 绝对路径。
   → 本技能的可移植版已改为 `os.path.join(out_dir, out_name)`，第 4 个参数可指定输出目录，默认当前目录。

4. **build() 反斜杠续行**：Python 里用 `\` 续行拼接字符串容易出错。
   → 用列表 `parts=[...]` + `"".join(parts)` 拼接，稳。

5. **阶段号对齐**：`PHASE_*` 的键必须覆盖所有阶段号，否则渲染时 `KeyError`。
   → 生成前确认阶段数 = 天数/3，三个字典键一致。

6. **中文编码**：所有文件读写显式 `encoding='utf-8'`；数据文件头加 `# -*- coding: utf-8 -*-`。

---

## 四、移植到新设备

1. 拷贝整个 `study-plan-html-generator/` 目录到新设备 `~/.workbuddy/skills/` 下。
2. 依赖仅 Python 标准库（sys/os/io/html/importlib），无需 pip install。
3. 复制 `scripts/example_days.py` / `example_phase.py` 改名后编写新科目内容。
4. 运行生成器（数据文件目录需在 path 中）：
   ```bash
   python scripts/gen_subject.py <科目>_days <科目>_phase <科目>N天学习计划.html
   ```
5. 若要改仓库同步目标，修改 `make_js` 里的 `GH_USER` / `GH_REPO` / `LS_TOKEN`。

---

## 五、扩展建议

- **天数非 21**：改 `DAYS` 长度即可（如 30 天 = 10 阶段）。阶段介绍条按 `(phase-1)*3+1 ~ phase*3` 计算，
  若末阶段不足 3 天，可微调 `render_day` 里的阶段介绍文案。
- **换配色**：只改 `CSS` 顶部的 `:root` 变量（`--accent` 等）。纪律：禁用绿/青/斜体/楷体。
- **加科目导航页**：可在站点 `index.html` 里加卡片链接到各科 HTML，形成"总入口 + 多科"结构。

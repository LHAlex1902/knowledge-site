# 实战案例：接口自动化教程 → 7 个互动实验

记录一次完整的设计决策过程，作为同类任务的参照。

## 机制提炼决策表

源材料：一份 12 章的《Python 接口自动化测试》教程。候选机制筛选原则：**有因果、有误解、可操作**。

| 实验 | 机制 | 结论锚句 | 破除的误解 | 控件 | 真理模型输入→输出 |
|---|---|---|---|---|---|
| ① | HTTP 状态码 | 路径错=404 不是 500；POST 成功=201 | 代码错=服务器崩=500 | 方法/路径/请求体/鉴权头 | (method,path,body,auth)→状态码+响应体 |
| ② | token 关联 | token 不会自动携带，要提取+放请求头 | 登录一次全程有效 | 提取开关/携带开关 | (extracted,carried)→200 或 401 |
| ③ | 断言三层次 | 200 ≠ 用例通过 | 状态码对=接口对 | 场景切换（4 种响应） | (http,code,字段)→三层各自判定 |
| ④ | 数据驱动 | 每组独立用例，一组失败不影响其它组 | 一组失败整批停止 | 可编辑数据表 | (age,expected)→逐组 PASS/FAIL |
| ⑤ | 请求完整流程 | 状态码是最后一环的产物 | ConnectionError 和 404 是一类问题 | URL 输入/超时开关 | url→失败环节(0-4)或状态码 |
| ⑥ | pytest 收集 | 命名不合规=静默消失 | 环境坏了 | 文件名/函数名输入 | (file,func)→收集/跳过 |
| ⑦ | fixture 前后置 | 用例失败清理仍执行 | 失败就中断不清理 | 用例结果切换 | mode→执行顺序动画+结论 |

## 真理模型伪代码示例（实验①）

```js
function simulate(method, path, body, auth){
  // 1. 受保护接口优先判鉴权
  if (path 以 /protected 开头) return auth ? 200 : 401;
  // 2. 路径合法性（正则白名单）
  if (path 不匹配 /users 或 /users/\d+) return 404;
  // 3. 按路径+方法分派
  //    GET /users/{id}: id=999→404 否则 200
  //    POST /users: body非法JSON→400, 缺name→400, 合法→201
  //    PUT: body非法→400 否则 200
  //    DELETE: 204（无响应体）
  //    方法不允许: 405
}
```

**关键设计**：405（方法不允许）是真实语义但新手不知道，保留它增加真实感；`/users/999` 专门设为不存在，让「资源不存在也是 404」可被操作验证。

## 真理模型单测清单（实验①，11 场景）

```
GET  /users        无token      → 200   （公开接口不需要鉴权）
GET  /users/1                   → 200
GET  /users/999                → 404   （资源不存在）
GET  /user                     → 404   （路径拼错）
POST /users       合法body      → 201   （创建成功，不是200）
POST /users       非法JSON      → 400
POST /users       缺必填字段    → 400
PUT  /users/1     合法body      → 200
DELETE /users/1                 → 204
GET  /protected   无token       → 401
GET  /protected   带token       → 200
```

实验⑤ URL 模型 6 场景：域名不存在+timeout→等待超时环节失败；端口无服务→TCP 环节；协议拼错/无协议→DNS 之前的 schema 校验；真实域名→正常走完全程。

## 报错文案真实化

模拟终端里的报错直接抄真实格式（脱敏改 host）：

```
requests.exceptions.ConnectionError: HTTPSConnectionPool(host='api.demo.com'):
Failed to resolve 'api.demo.com' ([Errno -2] Name or service not known)

requests.exceptions.ReadTimeout: HTTPSConnectionPool(host='...', port=443):
Read timed out. (read timeout=3)
```

这让学习者在实验里看到的报错和真实工作里一致，迁移零成本。

## 结构校验脚本要点

```python
# 1. quiz 的 data-q 与反馈 span id 对应
qs = re.findall(r'data-q="([^"]+)"', html)
missing = [q for q in qs if f'fb{q}' not in html]
# 2. tab 的 data-p 与 panel id 对应
# 3. panel 数、quiz 数、</html></body> 闭合
```

## JS 语法校验

```bash
python -c "提取 <script> 内容写入临时 js"
node --check _tmp_check.js
```

## 踩过的坑

1. **控件变化后预测题不重置** → 学习者用旧参数的答案蒙对新参数的题，教学失效。必须监听所有控件 input/change 事件重置预测题。
2. **预测判定绕过真理模型** → 预测题的正确答案必须由 simulate() 实时计算，不能写死，否则改参数后答案错乱。
3. **grep 提取中文标题乱码** → Windows bash 里 grep 处理 UTF-8 中文会乱码，改用 Python 脚本提取（`io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')`）。
4. **整门课压成一张图** → 违反「一图一机制」。正确做法是多实验+导航分组整合进一份文件。

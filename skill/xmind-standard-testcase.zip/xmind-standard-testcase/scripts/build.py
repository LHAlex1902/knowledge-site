# -*- coding: utf-8 -*-
"""测试用例 -> XMind 思维导图 + 配套 HTML 图形化预览器 通用生成器

数据驱动：读取一份 JSON 用例规格，同时产出两个文件：
  1) <name>.xmind          —— XMind Zen 格式（content.json + metadata.json + manifest.json）
  2) <name>-思维导图.html   —— 深色主题、图形化思维导图（节点卡片 + SVG 连接线），
                              可折叠/缩放/平移，支持上传解析其它 .xmind

层级（链式）：模块 → 功能点 → 测试点 → 前提条件 → 操作步骤 → 预期结果
可选：根下前置一个「档位/参数定义」分支（gears 字段）。

用法：
  python build.py <spec.json> <output_dir> [--basename 文件名前缀]

spec.json 结构见 references/spec_format.md。
仅依赖标准库（json/zipfile/uuid/os/sys），无需 openpyxl / jszip 等第三方包。
"""
import json, zipfile, uuid, os, sys, argparse


def nid():
    return uuid.uuid4().hex[:20]


def topic(title, children=None):
    t = {"id": nid(), "class": "topic", "title": title}
    if children:
        t["children"] = {"attached": children}
    return t


def build_xmind(spec, out_path):
    """根据 spec 生成 .xmind 文件。"""
    root_title = spec.get("title", "测试用例（E3未验证）")
    sheet_title = spec.get("sheet_title", "测试用例")

    root_children = []

    # 档位/参数定义分支（可选）
    gears = spec.get("gears") or []
    if gears:
        gear_label = spec.get("gears_branch_label", "档位定义")
        gear_nodes = [topic(f"{g['name']}：{g['param']}") for g in gears]
        root_children.append(topic(gear_label, gear_nodes))

    total = 0
    for mod in spec["modules"]:
        func_nodes = []
        for func in mod["functions"]:
            tp_nodes = []
            for t in func["tests"]:
                # 链式：测试点 → 前提条件 → 操作步骤 → 预期结果
                cur = topic(t["exp"])                       # 预期结果
                cur = topic(t["step"], children=[cur])      # 操作步骤
                cur = topic(t["pre"], children=[cur])       # 前提条件
                tp_nodes.append(topic(t["tp"], children=[cur]))  # 测试点
                total += 1
            func_nodes.append(topic(func["name"], tp_nodes))
        root_children.append(topic(mod["name"], func_nodes))

    root = topic(root_title, root_children)
    sheet_id = nid()
    content = [{
        "id": sheet_id,
        "class": "sheet",
        "title": sheet_title,
        "rootTopic": root,
        "topicPositioning": "fixed",
    }]
    metadata = {
        "creator": {"name": "testcase-xmind-generator", "version": "1.0"},
        "activeSheetId": sheet_id,
    }
    manifest = {"file-entries": {
        "content.json": {}, "metadata.json": {}, "manifest.json": {},
    }}

    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("content.json", json.dumps(content, ensure_ascii=False))
        z.writestr("metadata.json", json.dumps(metadata, ensure_ascii=False))
        z.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False))
    return total, len(spec["modules"])


# ---------------- HTML 图形化预览器 ----------------
HTML_TEMPLATE = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>__TITLE__ · 思维导图</title>
<script src="https://cdn.jsdelivr.net/npm/jszip@3.10.1/dist/jszip.min.js"></script>
<style>
  :root {
    --bg:#0d1117; --panel:#161b22; --border:#30363d; --text:#c9d1d9;
    --muted:#8b949e; --accent:#58a6ff;
  }
  * { box-sizing:border-box; }
  html,body { height:100%; }
  body { margin:0; font-family:"Microsoft YaHei","PingFang SC",system-ui,sans-serif;
         background:var(--bg); color:var(--text); overflow:hidden; }
  header { position:fixed; top:0; left:0; right:0; z-index:20; height:48px;
           background:rgba(13,17,23,.94); backdrop-filter:blur(8px);
           border-bottom:1px solid var(--border);
           padding:0 16px; display:flex; align-items:center; gap:12px; flex-wrap:wrap; }
  header h1 { font-size:15px; margin:0; font-weight:600; white-space:nowrap; }
  header .badge { color:var(--muted); font-size:12px; white-space:nowrap; }
  .spacer { flex:1; }
  button { background:var(--panel); color:var(--text); border:1px solid var(--border);
           padding:5px 11px; border-radius:6px; cursor:pointer; font-size:12px; }
  button:hover { border-color:var(--accent); color:var(--accent); }
  #canvas { position:absolute; inset:48px 0 0 0; overflow:hidden; cursor:grab; }
  #canvas.panning { cursor:grabbing; }
  #world { position:absolute; top:0; left:0; transform-origin:0 0; }
  #links { position:absolute; top:0; left:0; overflow:visible; pointer-events:none; z-index:1; }
  #links path { fill:none; stroke-width:1.6; }
  .node { position:absolute; z-index:2; padding:7px 12px; border-radius:8px;
          background:var(--panel); border:1px solid var(--border);
          font-size:13px; line-height:1.45; white-space:nowrap;
          box-shadow:0 2px 8px rgba(0,0,0,.35); cursor:default; user-select:none; }
  .node .lvl { display:block; font-size:10px; line-height:1.2; letter-spacing:.5px;
               color:var(--muted); opacity:.85; margin:-2px 0 2px; font-weight:400; }
  .node.d0 .lvl { color:rgba(255,255,255,.8); }
  .node.has-kids { cursor:pointer; }
  .node .tw { display:inline-block; width:14px; color:var(--muted); font-size:10px; }
  .node.leaf .tw { display:none; }
  /* 深度配色 */
  .d0 { background:#1f6feb; border-color:#1f6feb; color:#fff; font-weight:600; font-size:15px; padding:9px 16px; border-radius:10px; }
  .d1 { background:#1a2332; border-color:#2f81f7; color:#79c0ff; font-weight:600; }
  .d2 { background:#16241f; border-color:#2ea043; color:#56d364; }
  .d3 { background:#241b2f; border-color:#8957e5; color:#bc8cff; }
  .d4 { background:#1c2530; border-color:#388bfd; color:#a5d6ff; }
  .d5 { background:#1b2027; border-color:#484f58; color:#c9d1d9; }
  .d6 { background:#122117; border-color:#2ea043; color:#7ee787; }
  .gear-node { background:#241b2f; border-color:#bc8cff; color:#bc8cff; }
  #stat { position:fixed; bottom:12px; left:12px; z-index:20; background:var(--panel);
          border:1px solid var(--border); border-radius:6px; padding:6px 12px;
          font-size:12px; color:var(--muted); }
  #hint { position:fixed; bottom:12px; right:12px; z-index:20; color:var(--muted);
          font-size:11px; }
  #drop { position:fixed; inset:0; background:rgba(88,166,255,.12);
          border:2px dashed var(--accent); display:none; align-items:center;
          justify-content:center; z-index:100; font-size:20px; color:var(--accent); }
  #drop.show { display:flex; }
</style>
</head>
<body>
<header>
  <h1>🧠 __TITLE__</h1>
  <span class="badge">共 __TOTAL__ 条用例 · __MODS__ 个模块__GEARS_LABEL__</span>
  <span class="spacer"></span>
  <button onclick="expandAll(true)">全部展开</button>
  <button onclick="expandAll(false)">全部折叠</button>
  <button onclick="zoom(1)">放大</button>
  <button onclick="zoom(-1)">缩小</button>
  <button onclick="fit()">适应窗口</button>
  <button onclick="document.getElementById('file').click()">上传 .xmind</button>
  <input id="file" type="file" accept=".xmind" style="display:none" onchange="handleFile(this.files[0])">
</header>
<div id="canvas">
  <div id="world">
    <svg id="links"></svg>
    <div id="nodes"></div>
  </div>
</div>
<div id="stat"></div>
<div id="hint">Ctrl+滚轮缩放 · 拖拽空白平移 · 点击节点折叠</div>
<div id="drop">松开鼠标，上传 .xmind 预览</div>
<script>
const BUILTIN = __TREE_JSON__;
const XGAP = 56, YGAP = 12;

let root = null;
const world = document.getElementById('world');
const nodesEl = document.getElementById('nodes');
const svg = document.getElementById('links');
const canvas = document.getElementById('canvas');
let scale = 1, tx = 40, ty = 40;

function assignIds(node){
  node.id = node.id || Math.random().toString(36).slice(2,10);
  node.collapsed = false;
  (node.c||[]).forEach(assignIds);
}
function hasKids(n){ return n.c && n.c.length>0; }

// ---- 布局：左->右层级树，叶子顺序分配 y，父节点 y 取子节点中点 ----
function layout(){
  // 收集可见节点（折叠节点的子树不参与）
  const maxW = {};
  (function collect(n, depth){
    if(!n._w){ return; }
    maxW[depth] = Math.max(maxW[depth]||0, n._w);
    if(!n.collapsed && hasKids(n)) n.c.forEach(c=>collect(c, depth+1));
  })(root, 0);
  const xOf = {}; let acc = 0;
  Object.keys(maxW).map(Number).sort((a,b)=>a-b).forEach(d=>{
    xOf[d] = acc; acc += maxW[d] + XGAP;
  });
  let cursorY = 0;
  const pos = {};
  (function place(n, depth){
    const w = n._w, h = n._h, x = xOf[depth];
    const kids = (!n.collapsed && hasKids(n)) ? n.c : [];
    if(kids.length===0){
      pos[n.id] = {x, y: cursorY, w, h};
      cursorY += h + YGAP;
    } else {
      kids.forEach(c=>place(c, depth+1));
      const first = pos[kids[0].id], last = pos[kids[kids.length-1].id];
      pos[n.id] = {x, y: (first.y + last.y + last.h - h)/2, w, h};
    }
  })(root, 0);
  return pos;
}

function measure(){
  // 层级标注：根节点(depth0)不标，depth1=模块 … depth6=预期结果
  const LVL = ['模块','功能点','测试点','前提条件','操作步骤','预期结果'];
  // 渲染节点以测量尺寸
  nodesEl.innerHTML = '';
  (function build(n, depth){
    const el = document.createElement('div');
    let cls = 'node d'+Math.min(depth,6);
    if(n.gear) cls += ' gear-node';
    if(hasKids(n)) cls += ' has-kids'; else cls += ' leaf';
    el.className = cls;
    const lvl = document.createElement('span'); lvl.className='lvl';
    lvl.textContent = n.gear ? '' : (LVL[depth-1] || '');
    el.appendChild(lvl);
    if(!lvl.textContent){ lvl.style.display='none'; }
    const tw = document.createElement('span'); tw.className='tw';
    tw.textContent = n.collapsed ? '▸' : '▾';
    const txt = document.createElement('span'); txt.textContent = n.t;
    el.appendChild(tw); el.appendChild(txt);
    el.dataset.id = n.id;
    el.addEventListener('click', (e)=>{
      if(hasKids(n)){ e.stopPropagation(); n.collapsed = !n.collapsed; render(); }
    });
    nodesEl.appendChild(el);
    n._el = el;
    (hasKids(n) && !n.collapsed ? n.c : []).forEach(c=>build(c, depth+1));
  })(root, 0);
  // 测量
  (function measureAll(n){
    if(n._el){ n._w = n._el.offsetWidth; n._h = n._el.offsetHeight; }
    (n.c||[]).forEach(measureAll);
  })(root);
}

function drawLinks(pos){
  let d = '';
  const strokeByDepth = ['#1f6feb','#2f81f7','#2ea043','#8957e5','#388bfd','#484f58','#2ea043'];
  (function walk(n, depth){
    if(n.collapsed || !hasKids(n)) return;
    const p = pos[n.id];
    const x1 = p.x + p.w, y1 = p.y + p.h/2;
    n.c.forEach(c=>{
      const q = pos[c.id];
      const x2 = q.x, y2 = q.y + q.h/2;
      const mx = (x1 + x2)/2;
      const color = strokeByDepth[Math.min(depth,6)];
      d += '<path d="M'+x1+','+y1+' C'+mx+','+y1+' '+mx+','+y2+' '+x2+','+y2+'" stroke="'+color+'" opacity="0.55"/>';
      walk(c, depth+1);
    });
  })(root, 0);
  const bb = worldBounds(pos);
  svg.setAttribute('width', bb.w);
  svg.setAttribute('height', bb.h);
  svg.innerHTML = d;
}
function worldBounds(pos){
  let maxX=0, maxY=0;
  Object.values(pos).forEach(p=>{ maxX=Math.max(maxX,p.x+p.w); maxY=Math.max(maxY,p.y+p.h); });
  return {w:maxX+40, h:maxY+40};
}

function render(){
  measure();
  const pos = layout();
  // 定位节点
  Object.entries(pos).forEach(([id,p])=>{
    const el = nodesEl.querySelector('.node[data-id="'+id+'"]');
    if(el){ el.style.left = p.x+'px'; el.style.top = p.y+'px'; }
  });
  drawLinks(pos);
  applyTransform();
  updateStat();
}
function applyTransform(){
  world.style.transform = 'translate('+tx+'px,'+ty+'px) scale('+scale+')';
}

function updateStat(){
  let total = 0;
  (function count(n){
    if(!hasKids(n) || n.collapsed) return;
    n.c.forEach(c=>{
      if(hasKids(c) && !c.collapsed) count(c);
      else if(!hasKids(c)) {} // 叶子
    });
    // 统计测试点（深度3，即有 pre/step/exp 链的父节点）——简化：数所有叶子链
  })(root);
  // 简化统计：叶子总数
  let leaves = 0;
  (function cl(n){ if(n.collapsed||!hasKids(n)){ leaves++; return; } n.c.forEach(cl); })(root);
  document.getElementById('stat').textContent = '可见节点 '+leaves+' 个';
}

function expandAll(open){
  (function walk(n){
    if(hasKids(n)){ n.collapsed = !open; n.c.forEach(walk); }
  })(root);
  render();
}
function zoom(dir){
  scale = Math.min(2, Math.max(0.2, scale + (dir>0?0.15:-0.15)));
  applyTransform();
}
function fit(){
  const pos = layout();
  const bb = worldBounds(pos);
  const cw = canvas.clientWidth, ch = canvas.clientHeight;
  scale = Math.min(cw/bb.w, ch/bb.h, 1.2) * 0.92;
  tx = (cw - bb.w*scale)/2;
  ty = 24;
  applyTransform();
}

// ---- 平移 ----
let dragging=false, sx=0, sy=0, otx=0, oty=0;
canvas.addEventListener('mousedown', e=>{
  if(e.target.closest('.node')) return;
  dragging=true; canvas.classList.add('panning');
  sx=e.clientX; sy=e.clientY; otx=tx; oty=ty;
});
window.addEventListener('mousemove', e=>{
  if(!dragging) return;
  tx = otx + (e.clientX-sx); ty = oty + (e.clientY-sy); applyTransform();
});
window.addEventListener('mouseup', ()=>{ dragging=false; canvas.classList.remove('panning'); });
canvas.addEventListener('wheel', e=>{
  e.preventDefault();
  const delta = e.deltaY<0 ? 0.1 : -0.1;
  const rect = canvas.getBoundingClientRect();
  const cx = e.clientX-rect.left, cy = e.clientY-rect.top;
  const newScale = Math.min(2, Math.max(0.2, scale+delta));
  const ratio = newScale/scale;
  tx = cx - (cx-tx)*ratio; ty = cy - (cy-ty)*ratio; scale = newScale;
  applyTransform();
}, {passive:false});

// ---- 解析上传的 .xmind ----
function parseXmindContent(data){
  function conv(t){ return {t:t.title, c:(t.children&&t.children.attached||[]).map(conv)}; }
  return conv(data[0].rootTopic);
}
async function handleFile(file){
  if(!file) return;
  if(typeof JSZip==='undefined'){ alert('JSZip 未加载（离线时无法解析上传文件）'); return; }
  const zip = await JSZip.loadAsync(file);
  const f = zip.file('content.json');
  if(!f){ alert('未找到 content.json，可能不是有效的 .xmind 文件'); return; }
  const data = JSON.parse(await f.async('string'));
  root = parseXmindContent(data);
  assignIds(root); render(); fit();
}
const drop = document.getElementById('drop');
window.addEventListener('dragover', e=>{ e.preventDefault(); drop.classList.add('show'); });
window.addEventListener('dragleave', e=>{ if(e.target===drop) drop.classList.remove('show'); });
window.addEventListener('drop', e=>{ e.preventDefault(); drop.classList.remove('show');
  if(e.dataTransfer.files[0]) handleFile(e.dataTransfer.files[0]); });

// ---- 初始化 ----
root = BUILTIN;
assignIds(root);
render();
fit();
</script>
</body>
</html>"""


def build_html(spec, tree, total, modules_count, out_path):
    root_title = spec.get("title", "测试用例")
    gears = spec.get("gears") or []
    gears_label = (" · " + str(len(gears)) + " 档") if gears else ""
    tree_json = json.dumps(tree, ensure_ascii=False)
    html = HTML_TEMPLATE
    html = html.replace("__TITLE__", root_title)
    html = html.replace("__TOTAL__", str(total))
    html = html.replace("__MODS__", str(modules_count))
    html = html.replace("__GEARS_LABEL__", gears_label)
    html = html.replace("__TREE_JSON__", tree_json)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html)


def build_tree_for_html(spec):
    """构建 HTML 用的 {t,c} 嵌套树（与 xmind 结构一致）。"""
    def testpoint(t):
        return {"t": t["tp"], "c": [
            {"t": t["pre"], "c": [
                {"t": t["step"], "c": [
                    {"t": t["exp"], "c": []},
                ]},
            ]},
        ]}
    root_children = []
    gears = spec.get("gears") or []
    if gears:
        gear_label = spec.get("gears_branch_label", "档位定义")
        root_children.append({
            "t": gear_label,
            "gear": True,
            "c": [{"t": f"{g['name']}：{g['param']}", "gear": True, "c": []} for g in gears],
        })
    for mod in spec["modules"]:
        fnodes = []
        for func in mod["functions"]:
            fnodes.append({"t": func["name"], "c": [testpoint(t) for t in func["tests"]]})
        root_children.append({"t": mod["name"], "c": fnodes})
    return {"t": spec.get("title", "测试用例"), "c": root_children}


def main():
    ap = argparse.ArgumentParser(description="测试用例 -> XMind + 图形化 HTML 生成器")
    ap.add_argument("spec", help="JSON 用例规格路径")
    ap.add_argument("output_dir", help="输出目录")
    ap.add_argument("--basename", default="测试用例", help="输出文件名前缀")
    args = ap.parse_args()

    with open(args.spec, "r", encoding="utf-8") as f:
        spec = json.load(f)

    os.makedirs(args.output_dir, exist_ok=True)
    xmind_path = os.path.join(args.output_dir, f"{args.basename}.xmind")
    html_path = os.path.join(args.output_dir, f"{args.basename}-思维导图.html")

    total, mods = build_xmind(spec, xmind_path)
    tree = build_tree_for_html(spec)
    build_html(spec, tree, total, mods, html_path)

    print("SAVED:", xmind_path)
    print("SAVED:", html_path)
    print("模块数:", mods)
    print("用例总数:", total)


if __name__ == "__main__":
    main()

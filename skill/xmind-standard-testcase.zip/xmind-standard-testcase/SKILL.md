---
name: xmind-standard-testcase
description: "标准 XMind 测试用例生成技能。Generate a test-case mind map deliverable as both an XMind (.xmind) file and a matching self-contained GRAPHICAL HTML mind map (rendered as a real node-and-connector diagram, not a plain text outline) from a structured JSON spec. This skill should be used when the user wants to turn test cases or a test-case outline (module - function point - test point - precondition - steps - expected result) into an XMind mind map, optionally with a weak-network or parameter gear branch, and wants a browser-viewable graphical HTML version too. Triggers: 生成测试用例思维导图, 标准xmind测试用例, 把用例做成xmind, 测试用例转xmind, 用例思维导图html, 弱网测试用例导图."
agent_created: true
---

# 标准 XMind 测试用例生成器

把结构化的测试用例一键转成两个配套产物：
1. **`.xmind`** —— XMind Zen 格式，用 XMind 直接打开
2. **`-思维导图.html`** —— 深色主题、**图形化思维导图**（节点卡片 + SVG 曲线连接线，按层级着色），支持点击折叠、Ctrl+滚轮缩放、拖拽平移、一键适应窗口，并支持拖拽上传解析其它 `.xmind`

## 何时使用

- 用户要把测试用例（尤其是「模块 → 功能点 → 测试点 → 前提条件 → 操作步骤 → 预期结果」链式结构）做成 XMind 思维导图
- 用户要一个能在浏览器直接预览的配套 HTML 版本
- 弱网测试用例、功能测试用例等需要按层级组织成导图的场景

## 核心工作流

### 第 1 步：把用例整理成 spec.json

按 `references/spec_format.md` 的格式组织一份 JSON 规格。层级固定为：

**模块 → 功能点 → 测试点 → 前提条件 → 操作步骤 → 预期结果**

- 可选提供 `gears`（档位/参数定义，如弱网档位），会在根下生成一个「档位定义」分支
- 不需要功能点中间层时，让每个模块只含一个功能点
- 内容里避免出现英文直引号 `"`（会破坏 JSON），改用中文引号「」或弯引号

可复制 `assets/example_spec.json` 作为模板修改。

### 第 2 步：运行生成器

```bash
python scripts/build.py <spec.json> <output_dir> --basename <文件名前缀>
```

产出 `<output_dir>/<前缀>.xmind` 与 `<output_dir>/<前缀>-思维导图.html`。

脚本仅依赖 Python 标准库（json/zipfile/uuid），无需安装第三方包。建议用 WorkBuddy 受管 Python（`~/.workbuddy/binaries/python/versions/<版本>/python.exe`）或任意 Python 3 运行。

### 第 3 步：验证并交付

生成后抽查结构（XMind 是 zip，看 content.json 里 rootTopic 的 children.attached 链式嵌套），确认用例数、层级、有无残留关键词。确认无误后用 present_files 同时交付 `.xmind` 和 `-思维导图.html`（HTML 会自动打开预览面板）。

## 关键约定（本项目沉淀的经验）

- **链式结构**：测试点下的四层（前提条件 → 操作步骤 → 预期结果）串成一条链，每个是上一个的子节点，节点直接放内容、不加「前提条件：」这类前缀标签。
- **HTML 复用同一份 spec**：`build.py` 内部用同一套数据生成 xmind 和 html，改一处两边同步，避免不一致。
- **档位分支**：弱网类用例把档位参数集中在根下「档位定义」分支，用例步骤里直接引用档位名（如「在弱网下…」）。
- **上行/下行拆分**：需要区分方向丢包时（如阵容加载、结算），把「100%丢包」拆成「上行100%丢失」「下行100%丢失」两条独立用例。
- **证据等级**：此类用例集通常为 E3 未验证，建议并入根标题（如「…（E3未验证）」）。
- **中文引号坑**：写 spec 或脚本时，用例内容里的引号用中文弯引号，避免英文直引号提前闭合字符串/JSON。

## 资源

- `scripts/build.py` —— 数据驱动生成器，一份 spec.json 同时产出 xmind + 图形化 html（节点卡片 + SVG 连接线）
- `references/spec_format.md` —— spec.json 完整字段与结构说明
- `assets/example_spec.json` —— 可复制的示例规格（弱网用例模板）

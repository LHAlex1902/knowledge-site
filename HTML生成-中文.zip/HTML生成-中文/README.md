# HTML生成-中文（HTML 生成器 · 中文命名版）

一个用于 [WorkBuddy](https://www.workbuddy.cn) 的 Agent Skill：把任意技术工具/框架/库的知识，蒸馏成一份**单文件、可独立运行、深色主题、图标化**的交互式 HTML 技术教程 / 快速入门指南。

生成的 HTML 文件**用中文简要命名**（如 `ADB工具使用实操教程.html`），并带**与主题 emoji 匹配的渐变浏览器标签图标（favicon）**。输出风格对标 `ADB工具使用实操教程.html`——章节带编号与 emoji、子标题带编号、每章有「实操练习」、排查用方括号卡片、代码块带语言标签。

## 特性

- 🏷️ **中文文件命名**：输出 `ADB工具使用实操教程.html` 这类达意中文名，而非 `xxx-quickstart-guide.html`
- 🎨 **动态 favicon**：每份 HTML 带主题 emoji 的蓝色标签图标，美观且贴合内容
- 🎨 GitHub 风深色主题，单文件自包含（无外部 CDN 依赖）
- 🔢 「第 X 章 + emoji」编号章节 + 「X.Y 编号」子标题
- 🏷️ 代码块带语言标签（Python / C / C++ / Java / Shell 配色）
- ✎ 每章末尾「实操练习」块，⚠️【方括号】排查卡片
- 📋 一键复制、Tab 切换、折叠面板、步骤列表、流程图、时间线
- 📱 响应式适配（含移动端断点）

### 三条硬性编辑规范（最常被打回的地方）

1. **字体只允许三种身份**：正文/标题/强调 = 统一 UI 字体（靠继承，不写 `font-family`）；代码 = 等宽；**只有代码块内的注释用宋体**。楷体一律禁用，强调靠「红色加粗」而非换字体。
2. **代码注释靠右成列**：每行 = `<div class="cl"><span class="cd">代码</span><span class="code-ann">注释</span></div>`，`.code-ann` 带 `margin-left:auto; text-align:right`。注意 `<pre>` 内不能有换行符。
3. **每条注释必须讲清「含义 + 动机」**：用 `；` 分隔「这行在做什么」和「为什么这么写」。`# 宽度`、`# 返回`、`# 捕获所有异常` 这类只复述代码的注释**不合格**。且所有代码块都要有，不能前有后无。

交付前跑配套体检脚本（7 项全 0 才算过）：

```bash
python tools/check_html.py 教程.html
```

## 安装

将整个 `html-quickstart-guide-generator/` 文件夹放到 WorkBuddy 的技能目录：

- **用户级**（推荐，所有项目可用）：`~/.workbuddy/skills/`
- **项目级**（仅当前项目）：`<项目>/.workbuddy/skills/`

目录结构保持如下：

```
html-quickstart-guide-generator/
├── SKILL.md                    # 技能定义（触发词、设计规范、步骤、避坑）
├── _icon.svg                   # 技能图标
├── templates/
│   └── base-template.html      # HTML 骨架模板（含完整 CSS + 交互 JS）
└── tools/
    └── check_html.py           # 交付前体检：标签闭合 / 注释完整性 / 字体统一 等 7 项
```

重启 WorkBuddy 后，说「帮我生成 XX 的快速入门教程」「生成 XX 的 HTML 实操教程」即可触发。

## 触发词

快速入门、入门指南、学习路径、上手教程、实操教程、帮我学 XX、XX 怎么入门、生成 XX 的入门文档 / HTML 教程。

## 适用场景

pytest / requests / JMeter / Selenium / ADB / Fiddler / Redis / Docker / Git 等任何技术工具的快速入门与实操教程。

## 许可

MIT

#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""教程 HTML 交付前体检（本技能配套工具）。

用法：
    python check_html.py 教程.html [教程2.html ...]

检查项（合格值均为 0）：
    1. 标签闭合           —— 用 HTMLParser 维护栈比对，能抓出跨行 span、丢失的 </code>、未转义的裸标签
    2. 无注释的代码行      —— 逐行剥出 .cd，纯文本非空、不以 # 开头，却没有 .code-ann
    3. 注释挂错行          —— 有 .code-ann，但代码列纯文本为空（空行 / 纯注释行）
    4. <pre> 内含换行       —— 会被渲染成多余空行，行距翻倍
    5. 旧类 .ann 残留
    6. 楷体（KaiTi / 楷体）残留
    7. 字体种类            —— 只允许「统一 UI 字体 / 等宽 / 注释宋体」三种身份
"""
from __future__ import print_function
import io
import re
import sys
from html.parser import HTMLParser

VOID = {'br', 'img', 'meta', 'link', 'input', 'hr', 'source', 'track', 'wbr'}
OPEN_CD = '<span class="cd">'
OPEN_ANN = '<span class="code-ann">'
CL_SPLIT = re.compile(r'(?=<div class="cl">)')
PRE_RE = re.compile(r'<pre[^>]*>(.*?)</pre>', re.S)
ANN_RE = re.compile(r'<span class="code-ann">(.*?)</span>', re.S)


class TagChecker(HTMLParser):
    def __init__(self):
        HTMLParser.__init__(self)
        self.stack = []
        self.errs = []

    def handle_starttag(self, tag, attrs):
        if tag not in VOID:
            self.stack.append((tag, self.getpos()))

    def handle_endtag(self, tag):
        if tag in VOID:
            return
        if not self.stack:
            self.errs.append('多余的 </%s> @%s' % (tag, self.getpos()))
            return
        top, pos = self.stack.pop()
        if top != tag:
            self.errs.append('不匹配 <%s>@%s 被 </%s>@%s 关闭' % (top, pos, tag, self.getpos()))


def plain(frag):
    return re.sub(r'<[^>]+>', '', frag).replace('&nbsp;', '').strip()


def check(path):
    src = io.open(path, encoding='utf-8').read()
    print('=' * 72)
    print(path)
    print('=' * 72)
    ok = True

    tc = TagChecker()
    tc.feed(src)
    errs = list(tc.errs) + ['未闭合 <%s> @%s' % (t, p) for t, p in tc.stack]
    print('  1 标签闭合          :', 'OK' if not errs else '✗ %d 处' % len(errs))
    for e in errs[:6]:
        print('        ', e)
    ok = ok and not errs

    blocks = PRE_RE.findall(src)
    lost = misplaced = 0
    for b in blocks:
        for part in CL_SPLIT.split(b):
            if OPEN_CD not in part:
                continue
            has_ann = OPEN_ANN in part
            cd = part.split(OPEN_ANN, 1)[0]
            cd = cd[cd.index(OPEN_CD) + len(OPEN_CD):]
            k = cd.rfind('</span>')
            if k >= 0:
                cd = cd[:k]
            text = plain(cd)
            if text == '':
                # 空行上挂了注释 → 一定是行号错位
                if has_ann:
                    misplaced += 1
            elif text.startswith('#'):
                # 源码自带的注释行：可以配一条注释来解释它，属于正常
                pass
            elif not has_ann:
                lost += 1
    print('  2 无注释的代码行    :', lost)
    print('  3 注释挂错行        :', misplaced)
    ok = ok and lost == 0 and misplaced == 0

    nl = sum(1 for b in blocks if '\n' in b)
    print('  4 <pre> 内含换行     :', nl)
    ok = ok and nl == 0

    old = src.count('class="ann"')
    kai = src.count('KaiTi') + src.count('楷体')
    print('  5 旧类 .ann 残留     :', old)
    print('  6 楷体残留          :', kai)
    ok = ok and old == 0 and kai == 0

    fonts = sorted(set(m.strip() for m in re.findall(r'font-family\s*:[^;}]*', src)))
    print('  7 字体声明（%d 条）  :' % len(fonts))
    for f in fonts:
        print('        ', f)
    print('  ── 代码块 %d 个，注释 %d 条' % (len(blocks), len(ANN_RE.findall(src))))
    print('  结论：', '✔ 通过' if ok else '✘ 未通过，请按上面提示修正')
    return ok


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    allok = True
    for p in sys.argv[1:]:
        allok = check(p) and allok
    sys.exit(0 if allok else 2)

---
name: HTML生成-中文
description: |
  生成「图标化、章节编号化」的深色主题交互式 HTML 技术教程/快速入门指南的专用技能。当用户要求为某个技术工具/框架/库生成一份快速入门指南、学习路径、上手教程、实操教程（且期望输出为 HTML 格式）时触发。
  典型触发词：快速入门、入门指南、学习路径、上手教程、实操教程、帮我学XX、XX怎么入门、生成XX的入门文档、生成XX的HTML教程。
  输出特征：单文件 HTML，深色主题，带粘性导航栏、Hero 大标题+emoji+徽章、编号圆标章节（「第X章」）、带编号子标题、一键复制代码块（带语言标签）、Tab 切换、折叠面板、步骤列表、每章末尾「实操练习」块、方括号式排查卡片。生成的 HTML 文件用中文简要命名（如「ADB工具使用实操教程.html」），并带与主题 emoji 匹配的渐变浏览器标签图标（favicon）。风格参照 ADB工具使用实操教程.html。
  适用场景：pytest/requests/JMeter/Selenium/ADB/Fiddler/Redis/Docker/Git 等任何技术工具的快速入门与实操教程。
description_zh: "HTML 生成器（中文命名 · 图标化深色技术教程）"
description_en: "HTML Generator (Chinese naming · icon-rich dark tech tutorial)"
disable: false
agent_created: true
---

# HTML 生成器

将任意技术工具/框架/库的知识，蒸馏为一份**单文件、可独立运行、深色主题、图标化**的交互式 HTML 教程。输出风格统一参照 `ADB工具使用实操教程.html`——章节带编号与 emoji、子标题带编号、每章有「实操练习」、排查用方括号卡片、代码块带语言标签。

## When to use

- 用户要求为某个技术工具生成「快速入门」「入门指南」「学习路径」「上手教程」
- 用户希望输出为 HTML 格式（而非 Markdown / Word）
- 用户提到"和之前 pytest/requests/JMeter 一样的风格"
- 触发词示例：快速入门、入门指南、学习路径、上手教程、帮我学XX、XX怎么入门

## 核心设计系统

### CSS 变量（深色主题）

```css
:root {
  --bg: #0d1117;          /* 页面背景 */
  --bg-card: #161b22;     /* 卡片背景 */
  --bg-code: #0d1117;     /* 代码块背景 */
  --border: #30363d;      /* 边框 */
  --text: #c9d1d9;        /* 正文 */
  --text-muted: #8b949e;  /* 次要文字 */
  --text-heading: #f0f6fc;/* 标题 */
  --accent: #58a6ff;      /* 主色调（蓝） */
  --accent-green: #3fb950;
  --accent-orange: #d29922;
  --accent-red: #f85149;
  --accent-purple: #a371f7;
  --accent-cyan: #39d2c0;
  --radius: 8px;
}
```

### 语法高亮色

```css
.kw { color: #ff7b72; }      /* 关键字 */
.fn { color: #d2a8ff; }      /* 函数名 */
.str { color: #a5d6a7; }     /* 字符串 */
.cmt { color: #8b949e; }     /* 注释 */
.num { color: #79c0ff; }     /* 数字 */
.dec { color: #d2a8ff; }     /* 装饰器 */
.builtin { color: #ffa657; } /* 内置函数 */
```

## 图标化内容规范（核心，必须遵循）

输出风格对标 `ADB工具使用实操教程.html`。与朴素版本的**关键差异**在于内容层的图标化组织，而非 CSS（CSS 框架不变）。以下 7 条是标志性特征，逐条落实：

### 1. 章节标题用「第 X 章 + emoji + 标题」

每个 `<section>` 的 h2 用「第 X 章」中文编号，配一个贴合主题的 emoji，而非简短问句。

```html
<!-- ✅ 目标风格 -->
<h2><span class="num">1</span> 第 1 章 🤖 认识 ADB</h2>
<h2><span class="num">2</span> 第 2 章 🔌 设备连接管理</h2>
<!-- ❌ 朴素风格（避免） -->
<h2><span class="num">1</span> ADB 是什么？</h2>
```

### 2. 子标题带编号（X.Y 形式）

章节内的 h3 用「编号 + 图标 + 标题」，与章编号呼应。

```html
<h3>1.1 📌 什么是 ADB</h3>
<h3>1.2 🎯 核心用途</h3>
<h3>2.1 🔍 查看设备</h3>
```

### 3. 每章末尾加「✎ 实操练习」块

每章结束前放一个带图标的练习卡片，给出可动手的小任务，强化「实操教程」属性。

```html
<div class="card success">
  <strong>✎ 实操练习</strong>
  <ol>
    <li>连接手机后执行 <code>adb devices</code>，确认能看到设备序列号。</li>
    <li>尝试用 <code>adb reboot</code> 重启设备并观察。</li>
  </ol>
</div>
```

### 4. 排查/避坑用「方括号图标卡片」

故障排查、常见坑用带 <b>【图标 标题】</b> 方括号的卡片，视觉醒目，区别于普通提示。

```html
<div class="card warning">
  <b>⚠️【连不上排查】</b>
  <ul>
    <li>确认手机已开启「USB 调试」。</li>
    <li>换数据线 / 换 USB 口（部分线只供电）。</li>
    <li>执行 <code>adb kill-server &amp;&amp; adb start-server</code> 重启服务。</li>
  </ul>
</div>
```

### 5. 代码块 header 必须标语言/工具标签

`.code-block .header` 的 `<span>` 写清语言或工具名（Shell / Python / ADB / SQL / YAML 等），让读者一眼知道代码类型。

```html
<div class="code-block">
  <div class="header"><span>Shell · ADB</span><button class="copy-btn" onclick="copyCode(this)">📋 复制</button></div>
  <pre><code>adb devices</code></pre>
</div>
```

### 6. 状态/错误码用「状态 → 含义 → 解决」三列表

涉及状态码、错误码、返回值的，用三列解读表，而非简单两列对比。

```html
<table>
  <tr><th>状态/返回</th><th>含义</th><th>如何解决</th></tr>
  <tr><td><code>0</code></td><td>成功</td><td>—</td></tr>
  <tr><td><code>device not found</code></td><td>未识别到设备</td><td>检查连接、开启 USB 调试</td></tr>
</table>
```

### 7. 图标密度与选型

- 章标题、子标题、卡片标题、练习块、排查块**都要带 emoji/图标**，但正文段落不堆砌。
- 图标贴合语义：连接🔌、查看🔍、安装📦、运行▶️、警告⚠️、成功✅、提示💡、练习✎、命令⌨️、网络🌐、数据库🗄️、日志📜。
- 导航 brand 与 Hero 用同一个主 emoji。

## 输出文件命名规范（核心，必须遵循）

生成的 HTML 文件**必须用中文简要命名**，让读者在文件管理器里一眼就看出内容，而非 `xxx-quickstart-guide.html` 这类英文技术名。参照 `ADB工具使用实操教程.html`。

### 命名格式

`{主题}{文档类型}.html`，其中：

- **主题**：工具的中文简称或全名，如 `ADB`、`Git`、`Redis`、`Docker`、`JMeter`、`Selenium`、`Python`、`C++`。
- **文档类型**：从下列中按用户语境选一个：
  - `实操教程`（偏动手操作、命令驱动，如 ADB）
  - `快速入门` / `入门教程`（偏概念+上手）
  - `学习指南` / `学习笔记`（偏知识梳理、回顾，如整理用户自己的代码记录）
  - `实战手册` / `速查手册`（偏查阅）

### 命名示例

| 场景 | ✅ 正确命名 | ❌ 避免 |
|------|------------|--------|
| ADB 命令操作教程 | `ADB工具使用实操教程.html` | `adb-quickstart-guide.html` |
| Git 上手教程 | `Git版本控制快速入门.html` | `git-guide.html` |
| 用户 C/C++ 学习记录整理 | `C++自学笔记与代码回顾.html` | `c-cpp-learning-journey.html` |
| Python 学习笔记逐行注释 | `Python基础学习笔记详解.html` | `python-notes.html` |
| Redis 实战 | `Redis实战速查手册.html` | `redis-cheatsheet.html` |

### 命名要点

- **中文优先**：文件名用中文，简洁达意；工具名本身是英文缩写（ADB/Git/Redis）时保留英文缩写，其余用中文。
- **不用空格**：中文文件名不加空格与特殊符号，避免跨平台与 URL 问题（`ADB工具使用实操教程.html` 而非 `ADB 工具 教程.html`）。
- **与页面标题一致**：文件名的中文描述应与页面 `<title>` / Hero `<h1>`（`{{DOC_TITLE}}`）保持一致或高度呼应。
- **用户指定优先**：若用户明确给了文件名，直接用用户的；本规范用于用户未指定时的默认命名。

## 浏览器标签图标（favicon，必须包含）

每份生成的 HTML 都要在 `<head>` 中包含一个**动态 favicon**——用与主题主 emoji（`{{EMOJI}}`）匹配的渐变圆角图标，让浏览器标签页显示一个美观、贴合内容的图标，而非默认空白/地球图标。模板已内置如下代码，只需把 `{{EMOJI}}` 替换为主题 emoji 即可：

```html
<link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='%2358a6ff'/><stop offset='1' stop-color='%233fb950'/></linearGradient></defs><rect width='100' height='100' rx='22' fill='url(%23g)'/><text x='50' y='68' font-size='58' text-anchor='middle' dominant-baseline='central'>{{EMOJI}}</text></svg>" type="image/svg+xml">
```

- emoji 需 URL 编码兼容（直接用 emoji 字符即可，浏览器会自行处理；`%23` 是 `#` 的编码，勿改）。
- 图标用蓝→绿渐变（`#58a6ff → #3fb950`）与深色主题主色调一致。
- 若主题无明确 emoji，用一个贴合技术的通用 emoji（教程📘 / 工具🛠️ / 学习🎓 / 命令⌨️）。

## 代码逐行注释规范（核心，必须遵循）

生成/改造带代码的 HTML 时，**代码块中的每一行代码后面都必须附带一条行内注释**，解释「**这行代码的含义**」与「**为什么这么写（动机）**」，而非只解释字面动作。这是本技能区别于普通代码展示的关键特征。

### 注释样式（强制：宋体 · 不加粗 · 不倾斜 · 常用注释色）

行内注释统一使用专用类 `.code-ann`，样式如下（**必须原样采用，不得改成楷体/彩色/加粗/倾斜**）：

```css
.code-ann {
  color: #6a9955;                                   /* 常用注释绿（VS Code 默认注释色），柔和不刺眼 */
  font-family: "SimSun","宋体","Noto Serif SC",serif; /* 中文宋体 */
  font-style: normal;                               /* 不倾斜 */
  font-weight: normal;                              /* 不加粗 */
  font-size: 12.5px;
  margin-left: 6px;
  white-space: normal;
}
```

- **颜色**：固定用常用注释绿 `#6a9955`（与代码语法高亮的灰色原注释 `#…`、彩色关键字区分开）。**禁止**用青绿色 `#7ee0c0`、蓝色等花哨色。
- **字体**：中文**宋体**（SimSun）。**禁止**用楷体（KaiTi）。
- **字形**：`font-style:normal`（不倾斜）、`font-weight:normal`（不加粗）。**禁止** `italic` 或 `bold/600`。
- 注释正文前可加一个低调的前缀符号（如 `⟳` 或 `// 讲解：`），但符号本身也要宋体、绿色、不加粗。

### 注释内容写法（最容易被做差的一环，必须严格执行）

每条行内注释 = 「**这行在做什么（含义）**」+「**为什么这么写 / 不这么写会怎样（动机）**」。
**用 `；` 把两半分开**，读者一眼就能分清哪是含义、哪是动机。

```html
<span class="kw">import</span> numpy <span class="kw">as</span> np <span class="code-ann"># 导入 numpy 简写 np；图像在 Python 里就是 ndarray，后面的像素运算全靠它</span>
resp = requests.get(url, timeout=10) <span class="code-ann"># 发 GET 请求；timeout=10 防网络卡死时无限等待，是健壮性基本功</span>
```

#### 硬性判定标准

| 不合格（只复述代码 / 只有含义） | 合格（含义 + 动机） |
|---|---|
| `# 宽度` | `# 记下宽度；算中心、算相对坐标、裁剪子图都要用，单独存一份免得每次重算` |
| `# 直接返回（不返回帧）` | `# 收到退出信号就直接返回；上层看到 None 就结束循环，这就是「优雅停止」的落点` |
| `# 捕获所有异常` | `# 捕获所有异常；截图失败可能是句柄失效、驱动异常、超时，逐种识别既没必要也不可靠` |
| `# 定义 Box 类` | `# 定义 Box 类；它一块矩形区域承担两个角色 —— 当搜索范围可缩小匹配面积，当结果可承载坐标和置信度` |
| `# 导入 threading` | `# 导入线程模块；截图被放在独立线程里跑，不阻塞主逻辑，否则一边截图一边判断会卡成幻灯片` |

**必须避免的写法**：
- ❌ 把代码用中文念一遍（`self.width = width` → `# 宽度`、`return` → `# 返回`）——这是注释，不是翻译。
- ❌ 只写「做什么」不写「为什么」——读者看完仍不知道这行该不该存在、能不能删。
- ❌ 一行的动机写成教科书段落（超过约 60 字就该拆或砍）——注释列只有 45% 宽，长了会折成好几行。

**自查方法**：逐条念一遍，如果某条注释**遮住代码**后无法让人明白「为什么要有这一行」，就重写它。

### 与「原代码注释」的区分

- 代码里作者原本写的 `# 注释`（灰色 `#8b949e`）原样保留，代表原始说明。
- 新增的 `.code-ann` 是**讲解层**，用宋体绿色追加在每行末尾，二者颜色不同、一眼可分。

### 适用范围

- **代码块内**的每一行有效代码都要跟一条 `.code-ann`（空行、纯花括号行可省）。
- **正文段落、表格、导读文字**里的强调**不要**用 `.code-ann`——它只服务于代码块内的逐行讲解。

## 正文重点强调规范（与代码注释区分）

正文里对**关键结论、流程、重点词**的强调，与代码注释是两套样式，必须分开：

- **代码注释**（`.code-ann`）：宋体、绿色 `#6a9955`、不加粗不倾斜——只出现在代码块内。
- **正文强调**：用 `<strong>`/`<b>`（或专用类 `.kai`），样式为**红色加粗**，**字体与正文完全一致（禁止换楷体）**——只出现在正文。

推荐在 CSS 中加一条低优先级规则，让正文 `strong/b` 统一变红加粗：

```css
/* 正文重点强调：红色加粗（优先级低于类规则，不误伤 .kp/.qa 等组件配色） */
strong, b { color: var(--accent-red); font-weight: 700; }   /* --accent-red: #f85149 */
```

要点：
- 红色固定用 `#f85149`（与 `--accent-red` 一致），加粗 `font-weight:700`。
- 该规则**优先级低于** `.kp b`、`.qa .lab` 等带类名的组件规则，因此这些组件内的关键词配色（蓝/绿/红标签）**不会被误伤**。
- 代码块（`<pre>`）内只有 `<span>` 语法高亮，**不含** `strong/b`，所以此规则不会污染代码区。
- 若页面正文强调用的是专用类（如 `.kai`），直接改其颜色变量/值为 `#f85149` 即可统一，无需逐处改行内样式。
- **强调只改颜色和字重，绝不换字体**：`.kai` 这类强调类一旦挂上 `font-family`（如楷体），正文里就会混进第二种字体，整页字体立刻不统一。正确写法：`.kai{color:var(--kai-color); font-weight:600}`。
- **禁止**把正文强调用成代码注释的宋体绿色——绿=代码注释，红=正文重点，两者语义不同、颜色必须区分。

## 全站字体统一规范（强制）

一份 HTML 里**只允许出现三种字体身份**，多一种都算不合格：

| 用途 | 字体 | 说明 |
|------|------|------|
| 正文 / 标题 / 卡片 / 表格 / 徽章 / 正文强调 | `var(--ui-font)` | **全站唯一**；其他元素一律靠继承，不写 `font-family` |
| 代码本身 | 等宽 `"Cascadia Code","Fira Code",Consolas,monospace` | 只用于 `<pre>` / `<code>` 及代码块内的代码文本 |
| 代码块内的注释（`.code-ann`） | 宋体 `"SimSun","宋体","Noto Serif SC",serif` | **全站仅此一处使用宋体** |

```css
:root{
  /* 全站唯一 UI 字体：标题、正文、卡片、表格、强调……一律继承它 */
  --ui-font:-apple-system,BlinkMacSystemFont,"Segoe UI","Microsoft YaHei","PingFang SC",sans-serif;
}
body{ font-family:var(--ui-font); }
```

- 除上述三处，**任何选择器都不写 `font-family`**；靠 CSS 继承自动统一。
- **禁止**在正文/标题/强调里出现楷体（`"KaiTi","楷体"`）、仿宋、黑体等第二字体——要突出就用**红色加粗**，不靠换字体。
- 代码块 header 里的语言标签（`.lang`）、文件名（`.fname`）属于「非代码文本」，与正文同字体即可，不要借机再引入新字体。

## 注释列布局（把注释推到右侧、整齐成列）

行内注释直接跟在代码后面，长注释会把代码挤得参差不齐、也看不清。推荐「**左侧代码 + 右侧注释列**」的行结构：

```html
<pre><code><div class="cl"><span class="cd">CODE</span><span class="code-ann"># 讲解</span></div>…</code></pre>
```

```css
.cl        { display:flex; align-items:baseline; gap:20px; }      /* 每行代码 = 一个 flex 行 */
.cl > .cd  { white-space:pre; flex:0 0 auto; }                    /* 代码列，保留缩进与空格 */
.code-ann  { text-align:right; margin-left:auto; padding-left:24px; flex:0 0 auto; max-width:45%; }
```

- 关键就是 `.code-ann` 上的 **`margin-left:auto` + `text-align:right`**：注释会被推到最右并左右对齐成一整列。
- 源码自带的、**独立成行**的说明注释（`# …`）留在代码列的 `.cd` 里（用 `span.cmt`），不要搬到右侧注释列。
- **`<pre>` 内绝对不能出现换行符**：`<pre>` 保留空白，`.cl` 之间的 `\n` 会被渲染成空行，行距直接翻倍。用脚本批量生成时必须 `''.join(lines)` 无缝拼接，**不要** `'\n'.join(lines)`。
- 补注释要**补到底**：一份文档里不能出现「前几个代码块有逐行注释、后面几个没有」的情况——所有代码块的每一行有效代码都要带上 `.code-ann`。

## 把旧页面的行内注释升级为「注释列」（改造已有 HTML 的完整流程）

老页面常见写法是 `.ann` 类**贴在代码后面**（`margin-left:6px`）。升级成上面的注释列，只需改结构、**不改注释原文**。按下面顺序做，每步都能校验：

1. **先备份**：`shutil.copy(f, f + '.bak')`（中文路径用 Python 处理，别用 `cp`）。
2. **换 CSS**：把旧的 `.ann { … }` 整条规则替换为 `.cl` / `.cl > .cd` / `.code-ann` 三条；同时补一条 `.code-block pre code { display:block; }`（否则 `code` 还是 inline，背景和内边距会串行）。
3. **逐块重建行结构**（关键）：取出每个 `<pre>` 的内容 → 按 `<code …>` / `</code>` 剥出正文 → 按 `\n` 切行 → 每行用行尾正则剥出注释 → 重组成
   `<div class="cl"><span class="cd">代码</span><span class="code-ann">注释</span></div>`，最后 **`''.join(rows)`** 无缝拼回。
4. **再统一改名**：全部解析完成**之后**再做 `class="ann"` → `class="code-ann"` 的全量替换。顺序反了正则就找不到注释，会把注释当代码留在 `.cd` 里、同时重复插入一份新注释（踩过）。
5. **只修真正空洞的注释**：判断标准是「≤34 字且不含动机」以及「只说明这是 docstring / 只复述代码」。其余原文一律保留。
6. **跑体检**（下节 Verification 清单），全 0 才算完成。

### 这一步最容易踩的 5 个坑

| 坑 | 现象 | 处理 |
|---|---|---|
| **跨行 `span`** | 原文一个 `<span class="cmt">` 从第 12 行开到第 16 行，拆成逐行后标签错位、页面结构崩 | 拆行后必须让每行**自身闭合**：给这一组行各自补上 `.cmt` 开闭标签 |
| **丢了 `</code>`** | 重建时只拼 `.cl` 行、忘了把 `</code>` 拼回去，整块 `<code>` 未闭合 | 拼回时把剥出的 `open_tag`／`close_tag` 一起写回，最后用标签平衡校验兜底 |
| **注释里有裸标签** | 注释文字写了 `<a>`、`<select>`，浏览器把它当标签，后面的字全变成链接下划线 | 注释内容里的 `<` `>` 一律转义成 `&lt;` `&gt;`（注释里本不该有真标签） |
| **按行号批量替换注释** | 行号差一位 → 注释挂到空行、目标行漏改，**总数不变、只看数量发现不了** | 改之前用**同一个解析器**导出行号表；或直接用「旧注释原文 → 新注释」做内容匹配替换 |
| **`<pre>` 里混入换行** | 重建时用 `'\n'.join()` 拼行，渲染出成片空行、行距翻倍 | 一律 `''.join()` |

## 页面结构（必须遵循）

```
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{中文文档标题}</title>
  <link rel="icon" href="data:image/svg+xml,...主题emoji渐变图标...">
  <style>/* 完整 CSS */</style>
</head>
<body>
  <!-- 1. 顶部导航栏 (sticky topnav) -->
  <nav class="topnav">
    <span class="brand">📦 工具名 入门</span>
    <a href="#intro">简介</a>
    <a href="#install">安装</a>
    ...（各章节锚点）
  </nav>

  <!-- 2. Hero 区域 -->
  <header class="hero">
    <span class="emoji">📦</span>
    <h1>工具名 快速入门</h1>
    <p class="subtitle">从零到能上手 — 面向XX工程师的实战学习路径</p>
    <div class="badges">
      <span class="badge">⏱ 约 X 天掌握</span>
      <span class="badge green">🧪 代码即文档</span>
      <span class="badge orange">🎯 上手即用</span>
    </div>
  </header>

  <!-- 3. 内容容器 -->
  <div class="container">
    <!-- 各章节 section -->
    <section id="intro">...</section>
    <section id="install">...</section>
    ...
  </div>

  <!-- 4. 交互脚本 -->
  <script>
    // switchTab() / copyCode() / scroll highlight
  </script>
</body>
</html>
```

## 章节模板（标准 10-13 章结构）

| 序号 | 章节 ID | 内容 |
|------|---------|------|
| 1 | `intro` | 简介 — 是什么、为什么用、对比表、核心概念速览 |
| 2 | `install` | 安装配置 — Tab 切换多平台/多方式、插件一览 |
| 3 | `core` / `concepts` | 核心概念 — 流程图 + 组件表 + 类比 |
| 4-8 | 按主题 | 功能详解 — 代码示例 + 卡片提示 + Tab 切换 |
| 9 | `commands` | 常用命令速查 |
| 10 | `practice` | 实战案例 — 步骤列表 + 完整代码 |
| 11 | `cheatsheet` | 速查卡 — 命令/快捷键/变量/函数 |
| 12 | `next` | 下一步学什么 |

## 交互组件清单

### 1. Tab 切换

```html
<div class="tabs">
  <button class="tab-btn active" onclick="switchTab('group', 'tab1')">选项1</button>
  <button class="tab-btn" onclick="switchTab('group', 'tab2')">选项2</button>
</div>
<div class="tab-content active" id="group-tab1">...</div>
<div class="tab-content" id="group-tab2">...</div>
```

### 2. 代码块 + 一键复制（带语言标签）

```html
<div class="code-block">
  <div class="header">
    <span class="lang lang-py">Python</span>   <!-- 语言标签：lang-py/lang-c/lang-cpp/lang-java/lang-shell 等 -->
    <span class="fname">文件名 / 说明</span>
    <button class="copy-btn" onclick="copyCode(this)">📋 复制</button>
  </div>
  <pre><code>
<span class="cmt"># 注释</span>
<span class="kw">def</span> <span class="fn">hello</span>():
    <span class="builtin">print</span>(<span class="str">"world"</span>)
  </code></pre>
</div>
```
语言标签配色：Python 绿 `.lang-py`、C 蓝 `.lang-c`、C++ 紫 `.lang-cpp`、Java 红 `.lang-java`、Shell 橙 `.lang-shell`。无明确语言时用默认 `.lang`（蓝）。

### 3. 卡片（4 种类型）

```html
<div class="card tip">💡 提示内容</div>
<div class="card warning">⚠️ 警告内容</div>
<div class="card success">✅ 成功/验证内容</div>
<div class="card info">📋 信息/补充内容</div>
```

### 4. 步骤列表

```html
<ol class="step-list">
  <li><strong>步骤标题</strong><p>详细说明</p></li>
  <li><strong>步骤标题</strong><p>详细说明</p></li>
</ol>
```

### 5. 折叠面板

```html
<details class="accordion">
  <summary>点击展开的标题</summary>
  <div class="accordion-body">展开后的内容</div>
</details>
```

### 6. 流程图（水平排列）

```html
<div class="flow">
  <div class="flow-box accent">步骤A<br><small>说明</small></div>
  <span class="flow-arrow">→</span>
  <div class="flow-box">步骤B<br><small>说明</small></div>
  <span class="flow-arrow">→</span>
  <div class="flow-box">步骤C<br><small>说明</small></div>
</div>
```

### 7. 时间线（学习路径用）

```html
<div class="timeline">
  <div class="timeline-item">
    <h4>Day 1 — 标题</h4>
    <p>内容</p>
  </div>
  <div class="timeline-item">
    <h4>Day 2 — 标题</h4>
    <p>内容</p>
  </div>
</div>
```

### 8. 表格

```html
<table>
  <tr><th>列1</th><th>列2</th><th>列3</th></tr>
  <tr><td>数据</td><td>数据</td><td><code>code</code></td></tr>
</table>
```

## JavaScript 交互（必须包含）

```javascript
// Tab 切换
function switchTab(group, tab) {
  document.querySelectorAll(`[id^="${group}-"]`).forEach(el => el.classList.remove('active'));
  document.getElementById(`${group}-${tab}`).classList.add('active');
  const btns = document.querySelectorAll('.tabs .tab-btn');
  btns.forEach(b => {
    if (b.getAttribute('onclick').includes(`'${tab}'`)) b.classList.add('active');
    else b.classList.remove('active');
  });
}

// 一键复制
function copyCode(btn) {
  const pre = btn.closest('.code-block').querySelector('pre');
  navigator.clipboard.writeText(pre.textContent).then(() => {
    btn.textContent = '✅ 已复制'; btn.classList.add('copied');
    setTimeout(() => { btn.textContent = '📋 复制'; btn.classList.remove('copied'); }, 2000);
  }).catch(() => {
    btn.textContent = '❌ 失败';
    setTimeout(() => { btn.textContent = '📋 复制'; }, 2000);
  });
}

// 导航高亮
const sections = document.querySelectorAll('section[id]');
const navLinks = document.querySelectorAll('.topnav a');
window.addEventListener('scroll', () => {
  let current = '';
  sections.forEach(s => {
    if (window.scrollY >= s.offsetTop - 80) current = s.getAttribute('id');
  });
  navLinks.forEach(a => {
    a.classList.remove('active');
    if (a.getAttribute('href') === `#${current}`) a.classList.add('active');
  });
});
```

## Steps

1. **确认主题与受众**：明确要介绍的技术工具、目标读者（测试工程师/开发者/运维等）、预计学习天数
2. **规划章节结构**：根据工具特点确定 8-13 个章节，确保从"是什么→安装→核心概念→功能详解→实战→速查"的递进逻辑；为每章分配「第 X 章」编号与一个主题 emoji
3. **收集知识内容**：整理该工具的核心知识点、常用命令、代码示例、实战场景、常见报错与排查方法
4. **编写 HTML 文件**：
   - 使用 `@templates/base-template.html` 作为骨架
   - 章标题用「第 X 章 + emoji + 标题」，子标题用「X.Y + 图标 + 标题」
   - 代码块 header 必须标语言/工具标签（Shell / Python / ADB 等）
   - 代码示例必须完整可运行、带语法高亮 span
   - **代码块内每一行代码末尾都要追加 `.code-ann` 行内注释**（含义+动机），样式严格遵循「代码逐行注释规范」：宋体、不加粗、不倾斜、注释绿 `#6a9955`
   - 每个章节至少包含 1 个代码块 + 1 个对比表或卡片
5. **补充图标化组件**：
   - 每章末尾加「✎ 实操练习」块（success 卡片）
   - 故障/避坑用「⚠️【方括号标题】」排查卡片（warning 卡片）
   - 状态码/错误码用「状态→含义→解决」三列表
6. **添加交互组件**：Tab 切换（多平台安装/多种用法）、折叠面板（进阶内容）、步骤列表（操作流程）
7. **输出文件**：按「输出文件命名规范」用**中文**命名（如 `ADB工具使用实操教程.html`、`Git版本控制快速入门.html`），写入工作目录；确保 `<head>` 含动态 favicon（`{{EMOJI}}` 渐变图标）
8. **调用 present_files** 展示给用户

## Pitfalls

- **不要使用外部 CDN**：单文件必须完全自包含，不依赖任何外部资源
- **不要用 emoji 做 HTML ID**：ID 必须 ASCII，emoji 只出现在标题/brand/卡片文本中
- **代码块中的 `<` `>` 要转义**：使用 `&lt;` `&gt;` 避免被解析为 HTML 标签
- **Tab 的 group 名不能重复**：`switchTab('group', 'tab')` 的 group 必须唯一
- **导航锚点必须与 section id 对应**：`href="#intro"` 对应 `<section id="intro">`
- **响应式适配**：必须包含 `@media (max-width: 640px)` 断点
- **代码注释用中文**：注释说明"为什么这样做"而非"做了什么"
- **实战场景贴合用户背景**：如果用户是游戏测试工程师，示例用游戏相关场景
- **图标化不能省**：章标题/子标题/卡片/练习块/排查块必须带图标，这是本技能区别于朴素版本的核心特征——切勿只输出纯文字章节
- **文件名必须中文**：输出文件用中文简要命名（如「ADB工具使用实操教程.html」），禁止默认用 `xxx-quickstart-guide.html` 这类英文名；工具缩写（ADB/Git/Redis）可保留英文，其余用中文，不加空格
- **favicon 不能省**：每份 HTML 的 `<head>` 必须含动态 favicon（主题 emoji 蓝绿渐变图标），`{{EMOJI}}` 要替换为真实 emoji；这是让浏览器标签美观、贴合内容的关键
- **编号要连贯**：章编号「第 X 章」与子标题「X.Y」必须对应一致，不能跳号
- **代码逐行注释样式不能错**：代码块内每行末尾的行内讲解必须用 `.code-ann`——**宋体、不加粗、不倾斜、常用注释绿 `#6a9955`**；禁止用楷体、青绿色 `#7ee0c0`、加粗或倾斜。`.code-ann` 只用于代码块内，正文强调不要用它
- **改造已有 HTML 的注释样式**：若旧页面行内注释用了楷体/青绿色（如 `.ann`/`.kai` 的 `#7ee0c0`+KaiTi），要按新规范改：仅改 CSS 中该类的 `color`→`#6a9955`、`font-family`→宋体、`font-style`→normal、`font-weight`→normal；注意旧类若同时用于正文强调（如 `.kai`），需拆出新类只改代码块内的注释，避免误伤正文
- **正文强调 ≠ 代码注释颜色**：正文重点强调（`<strong>`/`<b>` 或 `.kai`）用**红色加粗 `#f85149`**，代码注释（`.code-ann`）用**宋体绿 `#6a9955`**——绿=代码注释、红=正文重点，语义不同必须区分。给 `strong,b` 加红时用低优先级规则（`.kp b`、`.qa .lab` 等类规则优先级更高，不会被误伤）；代码块内只有 `<span>` 不含 `strong/b`，不会污染代码区
- **字体只能有三种身份**：正文/标题/强调=统一 UI 字体（靠继承，不写 `font-family`）、代码=等宽、代码块注释=宋体。出现第四种字体（尤其楷体 `"KaiTi","楷体"`）就是不合格；强调一律用「红色加粗」实现，不靠换字体
- **注释不能前有后无**：同一份文档里，若前面的代码块有逐行注释、后面的代码块却没有，属于不合格交付。补注释时要逐块核对，确保**每个代码块的每一行有效代码**都带 `.code-ann`（空行、纯续行可省）
- **注释必须讲清「含义 + 动机」，不能只复述代码**（最常被打回的项）：`# 宽度`、`# 直接返回`、`# 捕获所有异常` 这类只念一遍代码的注释**一律不合格**；每条都要用 `；` 把「这行在做什么」和「为什么这么写 / 不这么写会怎样」分开写清。批量补注释时最容易图省事写成前者，务必逐条按上面的判定标准自查
- **批量改注释要防「错位」**：按行号批量替换注释时，脚本里的行号必须和实际 `.cl` 行序号严格对齐——差一位就会把注释挂到空行上、同时漏掉目标行。改完务必跑一次体检：**「空行/纯注释行却挂了注释」必须为 0**，**「无注释的代码行」必须为 0**（可用 `_tools/patch_ann.py` 里的体检逻辑）；只看总数相等是发现不了错位的
- **批量补注释的落地做法**（可复用）：用脚本按 `<div class="cl">` 切分行 → 把行尾的 `span.cmt` 提升为右侧 `.code-ann` → 对仍无注释的行查表补上 → 重新拼接；其中「独立成行的说明注释」保持原样不动。跑完必须校验：标签平衡、`<pre>` 内含换行数 = 0、各代码块「无注释的代码行」数为 0
- **改造已有 HTML 时批量加图标/标签的坑**（重要）：
  - 用正则给已有页面加 emoji 或语言标签时，**必须严格限定作用域**。给章标题加 emoji 只能匹配 `<h2>...</h2>` 内部，绝不能全局匹配 `<span class="num">`——因为代码块的语法高亮也用 `class="num"`（数字着色），全局替换会把 emoji 注入代码内容，破坏代码。
  - 判断"标题是否已带 emoji"不能用 `ord(ch) > 0x2000`（会把中文 CJK 误判为 emoji 导致跳过），要用精确区间：`0x1F000–0x1FAFF`（表情）+ `0x2600–0x27BF`（杂项符号）+ `0x2190–0x21FF`（箭头）+ `0x2B00–0x2BFF`。
  - 语言标签按文件扩展名判断时，fname 可能是 `xxx.cpp → 说明` 复合形式，要先取 `→` 前主体再判扩展名；无明确后缀时按所在章节设默认语言（如 C++ 章节默认 C++）。
  - 处理前务必 `.bak` 备份，处理后用脚本校验：标签平衡（div/section/pre 开闭相等）、代码块 `<pre>` 内 emoji 污染数为 0。

## Verification

- 文件名用中文简要命名（如「ADB工具使用实操教程.html」），非英文技术名
- 浏览器标签页显示主题 emoji 的渐变 favicon 图标
- 文件可直接在浏览器中打开运行（无需服务器）
- 所有 Tab 切换正常
- 复制按钮点击后显示"已复制"
- 导航栏滚动高亮正确
- 代码块内容完整、语法高亮 span 正确包裹
- 代码块内每行代码末尾都带 `.code-ann` 行内注释（含义+动机），样式为宋体、不加粗、不倾斜、注释绿 `#6a9955`；**所有代码块都要有，不能前几块有、后面没有**
- **抽查注释质量**：随机挑 5 条注释遮住代码读一遍，都能讲清「这行在做什么 + 为什么这么写」；不存在 `# 宽度` / `# 返回` 这类只复述代码的注释
- 注释无错位：没有任何注释挂在空行或纯注释行上，也没有任何有效代码行缺注释
- **字体已统一**：全文只有「统一 UI 字体 / 等宽代码字体 / 注释宋体」三种；正文、标题、强调里没有楷体等第二字体（`grep 'KaiTi\|楷体'` 应只命中代码注释的 CSS 定义或中文里的"楷体"字样说明）
- 注释列靠右对齐（`.code-ann` 带 `margin-left:auto; text-align:right`），并且 `<pre>` 内无换行符（不会被渲染出多余空行）
- 移动端（缩小窗口）布局不溢出

### 交付前的脚本体检（全 0 才算过）

改完 / 生成完必须跑一遍，这几项靠肉眼都看不出来：

| 检查项 | 合格值 | 怎么查 |
|---|---|---|
| 标签闭合 | 0 处错误、无未闭合 | `html.parser.HTMLParser` 维护栈比对（能抓出跨行 span、丢失的 `</code>`、裸标签） |
| 无注释的代码行 | 0 | 逐行剥出 `.cd`，纯文本非空且不以 `#` 开头却无 `.code-ann` → 计数 |
| 注释挂错行 | 0 | 有 `.code-ann` 但代码列纯文本为空（空行／纯注释行）→ 计数 |
| `<pre>` 内含换行 | 0 | `sum('\n' in b for b in pre_blocks)` |
| 旧类残留 | `class="ann"` = 0 | 字符串计数 |
| 楷体残留 | 0 | 计 `KaiTi` + `楷体` |

> 直接跑本技能自带脚本：`python tools/check_html.py 教程.html [更多.html …]`——上面 7 项一次全查，全 0 输出 `✔ 通过`。改完代码块结构后**必须**跑一遍再交付。
> **教训**：只要有一项没查，「总数看起来对」也会漏掉错位——本项目曾在块 6 上把注释整体挂错一行，注释总数完全没变。
